---
name: statistical-analysis
description: Analyse the user's data with them, step by step, in three separated phases (plan, execute, interpret) with a review by the user at every hand-over. Use when someone wants to answer a question from a dataset (CSV, Excel, ...) with statistics, including data-quality checks, cleaning, descriptive statistics and models, in Python or in R (R-Instat's curated packages), in English or French. Not for one-off calculations or explaining statistical concepts.
license: LGPL-3.0
compatibility: Needs code execution with Python 3.9+ and pandas, numpy and matplotlib (scipy and statsmodels for models). R analyses also need Rscript with R-Instat's packages, at least jsonlite.
metadata:
  source: analyst (IDEMS International), plan / execute / interpret
  generated-by: scripts/build_skills.py
---

<!-- Adapted from the analyst package's generated skill for WayPoint. -->

# Statistical analysis: plan, execute, interpret, with the user

Statistical analysis is better when planning, execution and interpretation are separate
phases, each held to its own best practice, with a human review at every hand-over. This
skill runs that workflow. You play three agents in turn (the **planner**, the **executor**
and the **interpreter**), each with its own playbook, and the user reviews what each one
hands to the next. `session.py` (in this skill's `scripts/` folder) holds the analysis state,
gives each agent its input, runs the code, and writes the hand-over documents.

Resolve `SKILL_DIR` to the directory containing this SKILL.md in the active plugin.
Run the script as `python "SKILL_DIR/scripts/session.py" ...` (`python3` where
`python` is missing). Substitute the actual directory path and quote paths that
may contain spaces.

## Rules that make it work

1. **It is not autonomous.** At every review point, show the hand-over, ask the user, and
   **wait for their answer**. Never answer a review point yourself or carry on past one,
   however obvious the answer.
   The only exception is a review point the user has switched off.
2. **One agent at a time, each with its own discipline.** Before acting as an agent for the
   first time (or when it is no longer in your context), read its reference file: it is that
   agent's role and playbook, exactly as the app gives them.
   - The planner proposes the next path up to the next decision point. It never runs code.
   - The executor writes and runs code for exactly the planned steps. It adds nothing,
     substitutes nothing, and reports every departure.
   - The interpreter checks adherence, sample sizes and assumptions, ties every finding to
     printed numbers and gives a verdict (`proceed` / `retry` / `revise` / `abandon` / `goal_met`). It does not decide what happens
     next; the planner does.
3. **Agents only know what they are handed.** Each agent works from the input that
   `session.py prompt` prints for it, as if it had not seen the other agents' reasoning. The
   interpreter judges the execution record, not what the executor meant to do.
4. **No analysis outside the workflow.** Do not open, summarise or plot the data with your
   own code: the brief's data profile and the interpreted results are all the planner knows,
   and every computation is a planned step run through `session.py run`.
5. **Never state a number that was not printed** by the analysis.
6. **`session.py` knows where you are.** Every command ends by saying what comes next. If
   unsure, run `session.py next RUN`. If a command answers `NOT DONE`, fix what it says.

## Start

1. Find out what you need, asking only for what the user has not already said: the goal (in
   their words), the data files, any context (notes, documents, questions they want
   answered, constraints), the **analysis language** (English unless they ask for French)
   and the **code language** (Python unless they ask for R).
2. Check the environment: `python "SKILL_DIR/scripts/session.py" check` (add
   `--code-language r` for R). If R is not available, say so plainly and offer Python.
3. Pick a writable run folder in the active workspace, such as
   `analysis-runs/<short-name>`. Use the resolved paths to the user's data files.
4. Start:
   ```
   python "SKILL_DIR/scripts/session.py" init RUN --goal "..." --data FILE [FILE ...] \
       [--note "..."] [--context-file FILE] [--query "..."] [--constraint "..."] \
       [--language fr] [--code-language r]
   ```
   This profiles the data and writes the brief. Its review point comes first.

## The loop

| Agent | Reference (read once) | Its input | It hands over |
|---|---|---|---|
| Planner | `references/<lang>-<code>/planner.md` | `session.py prompt RUN planner` | Plan JSON in a file, then `session.py plan RUN plan.json` |
| Executor | `references/<lang>-<code>/executor.md` | `session.py prompt RUN executor`, once per step | the step's code in a file, then `session.py run RUN step.py`; or `session.py fail RUN --reason "..."` |
| Interpreter | `references/<lang>-<code>/interpreter.md` | `session.py prompt RUN interpreter`, then open every figure it lists | Interpretation JSON in a file, then `session.py interpret RUN interp.json` |
| Report | `references/<lang>-<code>/report.md` | `session.py prompt RUN report` | the report in Markdown, then `session.py report RUN report.md` |

`<lang>-<code>` is the analysis's languages: `en-python`, `en-r`, `fr-python`, `fr-r`. Keep the agents' working
files (plan JSON, step code, interpretation JSON) in the run folder, e.g. `RUN/work/`.

- **Planner.** Its plan is one path that does one major thing, or questions for the user
  (`need_user_input`), or a proposal to finish (`complete`). Questions go to the user as
  their own review point.
- **Executor.** One step at a time: get the input, write that step's code, run it. Code runs
  in a fresh session that replays the node's earlier cells, so earlier objects exist. If it
  errors, `run` prints the fix instructions: fix the code without changing what the step
  computes, and run again (4 attempts in all). If you had to fix an obvious error
  in the plan's instructions, say so with `--change "what and why"`. If the output shows
  signs of a failed fit, `run` asks for a fit check: answer with
  `session.py fit RUN achieved|failed --notes "..."`. After the last step (or a failed one)
  the execution review point follows.
- **Interpreter.** Open every figure file the input lists, with your file or image viewing
  tool. If you cannot see images: Note: some figure(s) were produced but cannot be shown to this model. Judge from the printed output, and say which visual checks you could not make.
- **Report.** Comes after the user approves finishing, stops, or the planning budget
  (8 rounds) runs out.

## Review points

| Review point | The user sees | The user can |
|---|---|---|
| **brief** | goal, dataset profiles, context | approve (add notes, correct the goal), stop |
| **plan** | proposed paths, steps, methods, assumptions to check; or a proposal to finish | approve all or some paths, revise with feedback, stop |
| **execution** | code, output, figures, the executor's departures from the plan | approve (note for the interpreter), re-run with feedback, stop |
| **interpretation** | findings, verdict, issues, recommendation | approve (note for the planner), override the verdict, re-interpret, stop |

When a command prints `=== REVIEW POINT ... ===`, the user decides what happens next, in the
conversation, without opening any file:

1. **Show.** Post the **At a glance** section as printed (it is in the analysis language),
   then everything under `SHOW THE USER`: the data table, the questions' evidence, or each
   step's printed output (keep the tables in their code blocks, as printed). Show every
   `FIGURE:` file as the image itself, in its place, using the host's supported image display.
   In ChatGPT Work, use a Markdown image with an absolute `sandbox:` target. Give a figure's path only if you have no such tool.
   End with one line giving the full document's path, for whoever wants the code and detail.
2. **Ask with buttons.** Ask the questions under `ASK THE USER` with the host's question tool where supported: its `question`, `header` and `options` (each `label` with its
   `description`), and `multiSelect` where given. Every question lets the user add a comment
   (`comment` says what it is for) through the tool's free-text answer or notes. Ask a
   question marked `follow_up_for` only when the user picked that option. If the tool is unavailable
   or cannot represent the choices faithfully, list the options and let the user reply in words.
3. **Wait** for the answer. Do not comment on the analysis beyond what the document says.
   If the user asks about it, answer, and ask again.
4. **Run the command** of the chosen option (`RUN` is the run folder), adding the user's
   comment as `--feedback "..."` in their words. An option whose `comment` is `required`
   needs one: if they gave none, ask for it in one short line first. If they wrote their own
   answer instead of choosing, turn it into the closest command (`approve`, `revise`,
   `override --verdict ...`, `stop`, or `--answer q1="..."`); if you cannot tell which, ask.

Their comments become part of the analysis state and every later agent sees them. To stop
pausing at some review points (as trust builds), `session.py points RUN plan interpretation`
keeps only the ones listed; planner questions always wait for the user. When the execution
review point is off, its outputs and figures are shown at the interpretation review point.

## Where it runs

- Python needs pandas, numpy and matplotlib (scipy and statsmodels for models).
- R needs Rscript and R-Instat's packages. Set `ANALYST_R_LIBRARY` to use a dedicated
  library, or `ANALYST_RSCRIPT` if Rscript is not on PATH. In R, only R-Instat's curated
  packages and their dependencies may be loaded.
- If the active environment cannot run the bundled scripts, tell the user which
  capability is missing and pause execution. The reference playbooks can still guide
  a discussion about the analysis.

## Files

The run folder holds `state.json` (the analysis state), `trace.json` (the same shape as the
app's trace), `handoffs/` (every hand-over document, in order), one folder per executed node
(`n1a/`, ...) with its figures and its reproducible script (`analysis.py` or `analysis.R`),
and `report.md` at the end.
