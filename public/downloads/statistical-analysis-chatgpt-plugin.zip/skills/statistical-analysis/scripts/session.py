#!/usr/bin/env python3
"""The bookkeeping behind the statistical-analysis skill: what the app's graph and kernels do,
as commands an assistant runs between its own phases.

The assistant plays the planner, the executor and the interpreter in turn. This script holds
the analysis state (`<run>/state.json`), builds each phase's input exactly as the app does
(`prompt`), runs the executor's code by replaying the node's cells in a fresh Python or R
session (`run`), checks the planner's and interpreter's JSON against the app's schemas
(`plan`, `interpret`), writes the hand-over document at each review point and applies the
user's answer (`review`).

    session.py check [--code-language r]
    session.py init RUN --goal "..." --data FILE [--note "..."] [--language fr] [--code-language r]
    session.py next RUN                       what happens now, and which command does it
    session.py prompt RUN planner|executor|interpreter|report
    session.py plan RUN plan.json             the planner's output
    session.py run RUN step.py [--change "..."]
    session.py fail RUN --reason "..."        the executor reports a step not achievable as written
    session.py fit RUN achieved|failed --notes "..."
    session.py interpret RUN interpretation.json
    session.py review RUN approve|revise|override|stop [--feedback "..."] [--paths 0 1] [--verdict V] [--answer q1="..."]
    session.py points RUN plan interpretation   keep only these review points
    session.py report RUN report.md

i18n.py and codecheck.py are copies of the analyst package's modules, and _sources.py holds what
scripts/build_skills.py extracted from it (kernel workers, schemas, limits, R-Instat's package set).
This file mirrors analyst.graph, analyst.review, analyst.agents and analyst.ingest; the analyst
repository's tests check that its documents and prompts match the app's.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _sources as S  # noqa: E402
from i18n import code, number, p, t  # noqa: E402

FINAL = ("complete", "stopped", "out_of_budget")
FIT_WARNINGS = re.compile(S.FIT_WARNINGS, re.IGNORECASE)

# Lines this skill adds to the agents' inputs (the app passes figures as images instead).
EXTRA = {
    "en": {"figures": "Figure files (open each one and look at it):", "r_missing": "Not installed on this computer, "
           "so do not plan with them: {names}."},
    "fr": {"figures": "Fichiers des figures (ouvrez-les et regardez chacune) :", "r_missing": "Non installés sur cet "
           "ordinateur, ne les utilisez donc pas : {names}."},
}

# The skill's own wording for review points; button labels come from the review interface (S.UI_LABELS).
ASK = {
    "en": {"brief": "Is the brief right?", "plan": "Run this plan?", "finish": "Finish and write the report?",
           "execution": "Pass this execution to the interpreter?", "interpretation": "Accept this interpretation?",
           "h_brief": "Brief", "h_plan": "Plan", "h_execution": "Execution", "h_interpretation": "Interpret",
           "h_paths": "Paths", "h_verdict": "Verdict", "path": "Path {i}", "some": "Only some paths",
           "d_some": "Choose which paths to run", "d_brief": "The planner starts from this brief",
           "d_plan": "The executor runs the plan as it is", "d_finish": "The interpreter writes the final report",
           "d_revise": "Back to the planner with what to change", "d_not_done": "Back to the planner with what is missing",
           "d_exec": "The interpreter judges this execution", "d_rerun": "The executor runs the path again",
           "d_interp": "Back to the planner with this verdict", "d_override": "Replace the interpreter's verdict",
           "d_reinterpret": "The interpreter looks again", "d_stop": "End the analysis and write the report from what exists",
           "d_own": "Or write your own answer"},
    "fr": {"brief": "Le cadrage est-il juste ?", "plan": "Exécuter ce plan ?", "finish": "Terminer et rédiger le rapport ?",
           "execution": "Transmettre cette exécution à l'interprète ?", "interpretation": "Accepter cette interprétation ?",
           "h_brief": "Cadrage", "h_plan": "Plan", "h_execution": "Exécution", "h_interpretation": "Interprét.",
           "h_paths": "Pistes", "h_verdict": "Verdict", "path": "Piste {i}", "some": "Seulement certaines pistes",
           "d_some": "Choisir les pistes à exécuter", "d_brief": "Le planificateur part de ce cadrage",
           "d_plan": "L'exécutant suit le plan tel quel", "d_finish": "L'interprète rédige le rapport final",
           "d_revise": "Retour au planificateur avec ce qu'il faut changer",
           "d_not_done": "Retour au planificateur avec ce qui manque", "d_exec": "L'interprète juge cette exécution",
           "d_rerun": "L'exécutant relance la piste", "d_interp": "Retour au planificateur avec ce verdict",
           "d_override": "Remplacer le verdict de l'interprète", "d_reinterpret": "L'interprète réexamine",
           "d_stop": "Arrêter l'analyse et rédiger le rapport avec ce qui existe", "d_own": "Ou écrivez votre propre réponse"},
}


class Fail(Exception):
    """A message for the assistant: what is wrong and what to do instead."""


# =========================================================================== state


def state_file(run: Path) -> Path:
    return run / "state.json"


def load(run: Path) -> dict:
    f = state_file(run)
    if not f.is_file():
        raise Fail(f"No analysis at {run}. Start one with `session.py init {run} --goal ... --data ...`.")
    return json.loads(f.read_text(encoding="utf-8"))


def save(run: Path, state: dict) -> None:
    tmp = state_file(run).with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(state_file(run))


def trace(run: Path, state: dict) -> None:
    """The app's trace.json, so a skill run can be read like an app run."""
    keys = ("brief", "plans", "nodes", "user_log", "review_points", "status", "final_report")
    (run / "trace.json").write_text(json.dumps({k: state.get(k) for k in keys}, indent=2, ensure_ascii=False),
                                    encoding="utf-8")


def lang_of(state: dict) -> str:
    return state["settings"]["language"]


def fence_of(state: dict) -> str:
    return state["brief"]["code_language"]


def verdict_of(node: dict) -> str | None:
    """The verdict that counts: the user's override if any, else the interpreter's."""
    return node.get("user_verdict") or ((node.get("interpretation") or {}).get("verdict"))


def note(stage: str, action: str, feedback: str) -> dict:
    return {"stage": stage, "action": action, "text": feedback}


# =========================================================================== schemas


def _resolve(schema: dict, root: dict) -> dict:
    while "$ref" in schema:
        schema = root["$defs"][schema["$ref"].split("/")[-1]]
    return schema


def validate(value, schema: dict, root: dict, where: str = "$") -> list[str]:
    """The checks pydantic would make on the agent's JSON: required fields, types and coded values."""
    schema = _resolve(schema, root)
    if "anyOf" in schema:
        results = [validate(value, s, root, where) for s in schema["anyOf"]]
        return [] if any(not r for r in results) else results[0]
    if "enum" in schema and value not in schema["enum"]:
        return [f"{where}: {value!r} is not one of {', '.join(map(str, schema['enum']))}"]
    kinds = {"string": str, "integer": int, "boolean": bool, "array": list, "object": dict, "null": type(None),
             "number": (int, float)}
    kind = schema.get("type")
    if kind and (not isinstance(value, kinds[kind]) or (kind in ("integer", "number") and isinstance(value, bool))):
        return [f"{where}: expected {kind}, got {type(value).__name__}"]
    errors = []
    if isinstance(value, dict) and "properties" in schema:
        errors += [f"{where}: missing required field {k!r}" for k in schema.get("required", []) if k not in value]
        for k, v in value.items():
            if k in schema["properties"]:
                errors += validate(v, schema["properties"][k], root, f"{where}.{k}")
    if isinstance(value, list):
        errors += [e for i, v in enumerate(value) for e in validate(v, schema.get("items", {}), root, f"{where}[{i}]")]
    return errors


def complete_defaults(value, schema: dict, root: dict):
    """Fill missing optional fields with the schema's defaults, as pydantic's model_dump would show them."""
    schema = _resolve(schema, root)
    if "anyOf" in schema and value is not None:
        schema = next((_resolve(s, root) for s in schema["anyOf"] if _resolve(s, root).get("type") != "null"), schema)
    if isinstance(value, dict) and "properties" in schema:
        out = {}
        for k, sub in schema["properties"].items():
            if k in value:
                out[k] = complete_defaults(value[k], sub, root)
            elif "default" in sub:
                out[k] = json.loads(json.dumps(sub["default"]))
        return out
    if isinstance(value, list):
        return [complete_defaults(v, schema.get("items", {}), root) for v in value]
    return value


def read_model(source: str, name: str) -> dict:
    text = sys.stdin.read() if source == "-" else Path(source).read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise Fail(f"{source} is not valid JSON: {e}. Fix it and run the command again.")
    schema = S.SCHEMAS[name]
    errors = validate(data, schema, schema)
    if errors:
        raise Fail(f"{source} does not match the {name} format:\n" + "\n".join(f"- {e}" for e in errors[:20])
                   + "\nFix the JSON and run the command again.")
    return complete_defaults(data, schema, schema)


# =========================================================================== ingest (analyst.ingest)


def read_table(path: Path):
    import pandas as pd

    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".tsv":
        return pd.read_csv(path, sep="\t")
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix == ".json":
        return pd.read_json(path)
    raise Fail(f"Unsupported data file type: {path} (use one of {', '.join(sorted(S.DATA_SUFFIXES))}).")


def profile_column(s, lang: str) -> dict:
    import pandas as pd

    def n(x) -> str:
        return number(x, lang)

    n_missing = int(s.isna().sum())
    nonnull = s.dropna()
    n_unique = int(nonnull.nunique())
    if pd.api.types.is_bool_dtype(s):
        summary = t(lang, "prof.bool", n=int(nonnull.sum()))
    elif pd.api.types.is_numeric_dtype(s):
        if len(nonnull):
            d = nonnull.describe()
            summary = t(lang, "prof.numeric", min=n(d["min"]), median=n(nonnull.median()), mean=n(d["mean"]),
                        max=n(d["max"]), sd=n(d["std"]))
            if n_unique <= 10:
                summary += t(lang, "prof.few", n=n_unique)
        else:
            summary = t(lang, "prof.all_missing")
    elif pd.api.types.is_datetime64_any_dtype(s):
        summary = (t(lang, "prof.dates", start=nonnull.min(), end=nonnull.max()) if len(nonnull)
                   else t(lang, "prof.all_missing"))
    else:
        top = nonnull.astype(str).value_counts().head(6)
        summary = t(lang, "prof.levels", n=n_unique, levels=", ".join(f"{k!r} ({v})" for k, v in top.items()))
    return {"name": str(s.name), "dtype": str(s.dtype), "n_missing": n_missing, "n_unique": n_unique, "summary": summary}


def load_code(path: Path, name: str, code_language: str, df, workdir: Path) -> str:
    if code_language == "r":
        suffix = path.suffix.lower()
        if suffix == ".parquet":
            out = workdir.resolve()
            out.mkdir(parents=True, exist_ok=True)
            path = out / f"{name}.csv"
            df.to_csv(path, index=False)
            suffix = ".csv"
        lit = json.dumps(path.resolve().as_posix())
        na = "c(" + ", ".join(json.dumps(x) for x in S.R_NA) + ")"
        reader = {
            ".csv": f"readr::read_csv({lit}, na = {na}, show_col_types = FALSE)",
            ".tsv": f"readr::read_tsv({lit}, na = {na}, show_col_types = FALSE)",
            ".xlsx": f"readxl::read_excel({lit}, na = {na})",
            ".xls": f"readxl::read_excel({lit}, na = {na})",
            ".json": f"tibble::as_tibble(jsonlite::fromJSON({lit}))",
        }[suffix]
        return f"{name} <- {reader}"
    lit = str(path.resolve())
    reader = {
        ".csv": f"pd.read_csv(r'{lit}')",
        ".tsv": f"pd.read_csv(r'{lit}', sep='\\t')",
        ".xlsx": f"pd.read_excel(r'{lit}')",
        ".xls": f"pd.read_excel(r'{lit}')",
        ".parquet": f"pd.read_parquet(r'{lit}')",
        ".json": f"pd.read_json(r'{lit}')",
    }[path.suffix.lower()]
    return f"{name} = {reader}"


def var_name(stem: str) -> str:
    name = re.sub(r"\W+", "_", stem).strip("_").lower() or "data"
    return f"df_{name}" if name[0].isdigit() else name


def unique_name(name: str, used: set[str]) -> str:
    candidate, i = name, 2
    while candidate in used:
        candidate, i = f"{name}_{i}", i + 1
    used.add(candidate)
    return candidate


def read_context(path: Path) -> str:
    if path.suffix.lower() == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise Fail("Reading PDF context needs pypdf (`pip install pypdf`), or paste the text as a --note.")
        text = "\n".join(page.extract_text() or "" for page in PdfReader(path).pages)
    else:
        text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) > S.MAX_CONTEXT_CHARS:
        raise Fail(f"{path} is {len(text):,} chars; summarise it or split it first.")
    return text


def make_brief(goal: str, data: list[str], context_files: list[str], notes: list[str], queries: list[str],
               constraints: list[str], lang: str, code_language: str, workdir: Path) -> dict:
    if not goal or not goal.strip():
        raise Fail("A goal is required: what does the user want to achieve?")
    datasets, context, used = [], [], set()
    for path in map(Path, data):
        if not path.is_file():
            raise Fail(f"Data file not found: {path}")
        df = read_table(path)
        name = unique_name(var_name(path.stem), used)
        datasets.append({"name": name, "path": str(path.resolve()), "n_rows": len(df), "n_cols": df.shape[1],
                         "columns": [profile_column(df[c], lang) for c in df.columns],
                         "load_code": load_code(path, name, code_language, df, workdir)})
    context += [{"kind": "query", "source": "user", "content": q} for q in queries]
    for path in map(Path, context_files):
        if path.suffix.lower() in S.DATA_SUFFIXES:
            raise Fail(f"{path} looks like data; pass it with --data instead.")
        context.append({"kind": "file", "source": str(path), "content": read_context(path)})
    context += [{"kind": "note", "source": "user", "content": n} for n in notes]
    return {"goal": goal.strip(), "datasets": datasets, "context": context, "constraints": list(constraints),
            "code_language": code_language}


# =========================================================================== rendering (analyst.agents.base)


def render_brief(brief: dict, lang: str) -> str:
    out = [f"## {t(lang, 'r.goal')}\n{brief['goal']}"]
    if brief.get("constraints"):
        out.append(f"## {t(lang, 'r.constraints')}\n" + "\n".join(f"- {c}" for c in brief["constraints"]))
    for d in brief["datasets"]:
        cols = "\n".join(f"| {c['name']} | {c['dtype']} | {c['n_missing']} | {c['n_unique']} | {c['summary']} |"
                         for c in d["columns"])
        out.append(f"## {t(lang, 'r.dataset', name=d['name'], rows=d['n_rows'], cols=d['n_cols'])}\n"
                   f"{t(lang, 'r.loaded', name=d['name'])}\n\n{t(lang, 'r.columns')}\n|---|---|---|---|---|\n{cols}")
    for c in brief.get("context", []):
        out.append(f"## {t(lang, 'r.' + c['kind'])} ({c['source']})\n{c['content']}")
    return "\n\n".join(out)


def render_user_notes(notes: list[dict], stages: tuple[str, ...], lang: str) -> str:
    relevant = [n for n in notes if n["stage"] in stages and n["text"].strip()]
    if not relevant:
        return ""
    return (p(lang, "notes.head") + "\n\n"
            + "\n".join(f"- {p(lang, 'notes.item', stage=n['stage'], action=n['action'])} {n['text']}" for n in relevant)
            + "\n\n")


def render_path(path: dict, lang: str, fence: str) -> str:
    steps = "\n".join(
        f"{i + 1}. {s['description']}\n   - {p(lang, 'path.method')}: {s['method']}\n   - {p(lang, 'path.expected')}: "
        f"{s['expected_output']}"
        + (f"\n   - {p(lang, 'path.code')}:\n```{fence}\n{s['suggested_code']}\n```" if s.get("suggested_code") else "")
        for i, s in enumerate(path["steps"]))
    out = (f"### {path['title']}\n{p(lang, 'path.purpose')}: {path['purpose']}\n\n{p(lang, 'path.steps')}:\n{steps}\n\n"
           f"{p(lang, 'path.evaluate')}: {path['evaluate_at']}\n")
    out += f"{p(lang, 'path.criteria')}:\n" + "\n".join(f"- {c}" for c in path["success_criteria"])
    if path.get("assumptions_to_check"):
        out += f"\n{p(lang, 'path.assumptions')}:\n" + "\n".join(f"- {a}" for a in path["assumptions_to_check"])
    return out


def render_tree(nodes: dict, lang: str) -> str:
    if not nodes:
        return t(lang, "r.empty")
    lines = []
    for n in nodes.values():
        interp = n.get("interpretation")
        head = "- " + t(lang, "r.node", id=n["id"], parent=n["parent"], title=n["path"]["title"])
        if n.get("execution") is None:
            lines.append(head + f" [{t(lang, 'r.planned')}]")
            continue
        if interp is None:
            lines.append(head + f" [{t(lang, 'r.not_interpreted', status=n['execution']['status'])}]")
            continue
        verdict = t(lang, "r.verdict")
        if n.get("user_verdict") and n["user_verdict"] != interp["verdict"]:
            lines.append(head + f" -> {verdict} **{n['user_verdict']}** ({t(lang, 'r.override', verdict=interp['verdict'])})")
        else:
            lines.append(head + f" -> {verdict} **{interp['verdict']}**")
        for un in n.get("user_notes", []):
            lines.append(f"    - {t(lang, 'r.user', stage=un['stage'], action=un['action'])}: {un['text']}")
        for f in interp["findings"]:
            lines.append(f"    - {t(lang, 'r.finding', level=f['confidence'])}: {f['statement']} [{f['evidence']}]")
        for i in interp["issues"]:
            lines.append(f"    - {t(lang, 'r.issue')}: {i['problem']}" + (f" [{i['evidence']}]" if i["evidence"] else "")
                         + (f" {t(lang, 'r.fix')}: {i['proposed_fix']}" if i["proposed_fix"] else ""))
        lines.append(f"    - {t(lang, 'r.recommends')}: {interp['recommendation_for_planner']}")
        if n["execution"].get("variables"):
            lines.append(f"    - {t(lang, 'r.objects')}: {n['execution']['variables']}")
    return "\n".join(lines)


def figures_of(record: dict) -> list[str]:
    return [f for s in record["steps"] for c in s["cells"] if c.get("error") is None for f in c["figures"]]


def render_execution(record: dict, lang: str, fence: str) -> str:
    attached = set(figures_of(record)[:S.MAX_FIGURES])
    parts = []
    for s in record["steps"]:
        parts.append(p(lang, "interp.step", i=s["step_index"] + 1, status=s["status"]))
        if s["deviations"]:
            parts.append(p(lang, "interp.deviations") + "\n" + "\n".join(f"- {d}" for d in s["deviations"]))
        for j, c in enumerate(s["cells"]):
            if j < len(s["cells"]) - 1:
                parts.append(f"{p(lang, 'interp.failed_attempt', i=j + 1)}\n```\n{(c.get('error') or '').strip()[-800:]}\n```")
                continue
            parts.append(f"{p(lang, 'interp.code')}\n```{fence}\n{c['code']}\n```\n{p(lang, 'interp.output')}\n```\n"
                         f"{c['stdout']}\n```")
            if c.get("error"):
                parts.append(f"{p(lang, 'interp.error')}\n```\n{c['error']}\n```")
            if c["figures"]:
                parts.append(p(lang, "interp.figures") + ", ".join(
                    Path(f).name + ("" if f in attached else p(lang, "interp.not_attached")) for f in c["figures"]))
    skipped = len(record["path"]["steps"]) - len(record["steps"])
    if skipped:
        parts.append(p(lang, "interp.skipped", n=skipped))
    text = "\n\n".join(parts)
    if len(text) > S.MAX_OUTPUT_CHARS:
        text = text[:S.MAX_OUTPUT_CHARS] + "\n\n" + p(lang, "interp.truncated")
    return text


def summarise_step(s: dict, lang: str, fence: str) -> str:
    last = s["cells"][-1] if s["cells"] else None
    return p(lang, "exec.summary", i=s["step_index"] + 1, status=s["status"], code=last["code"] if last else "",
             out=(last["stdout"] if last else "")[-2000:], fence=fence)


# =========================================================================== hand-over documents (analyst.review)


def lbl(lang: str, key: str, **kw) -> str:
    return t(lang, key, **kw) + (" :" if lang == "fr" else ":")


def first_sentences(text: str, n: int) -> str:
    parts = text.replace("\n", " ").split(". ")
    return ". ".join(parts[:n]).rstrip(".") + ("." if parts else "") + (" ..." if len(parts) > n else "")


def short(text: str, n: int = 70) -> str:
    text = text.replace("\n", " ").replace("|", "/")
    return text if len(text) <= n else text[: n - 3] + "..."


def rel(path: str | Path, start: Path) -> str:
    try:
        return Path(os.path.relpath(path, start)).as_posix()
    except ValueError:  # different drive on Windows
        return Path(path).as_posix()


def indent(text: str) -> str:
    return "\n".join("   " + line for line in text.splitlines())


def brief_summary(brief: dict, lang: str) -> str:
    data = "\n".join("- " + t(lang, "brief.dataset", name=d["name"], rows=d["n_rows"], cols=d["n_cols"],
                                missing=sum(c["n_missing"] > 0 for c in d["columns"])) for d in brief["datasets"])
    return (f"**{lbl(lang, 'brief.goal')}** {brief['goal']}\n\n**{lbl(lang, 'brief.data')}**\n"
            f"{data or '- ' + t(lang, 'brief.none')}\n\n**{lbl(lang, 'brief.context')}** {len(brief['context'])}")


def plan_lead(plan: dict, lang: str) -> str:
    phase = f"**{code(lang, plan['phase'])}** · " if plan.get("phase") else ""
    return phase + (plan["summary"] or first_sentences(plan["situation"], 2))


def plan_summary(plan: dict, lang: str) -> str:
    if plan["decision"] == "complete":
        return f"**{t(lang, 'title.finish')}.**\n\n{plan['summary'] or first_sentences(plan['rationale'], 3)}"
    out = [plan_lead(plan, lang), t(lang, "plan.branching", parent=plan["parent_node"])]
    for i, path in enumerate(plan["paths"]):
        steps = "\n".join(f"{j + 1}. {s['description']} *({s['method']})*" for j, s in enumerate(path["steps"]))
        out.append(f"**{t(lang, 'plan.path', i=i, title=path['title'])}**\n\n{steps}")
    return "\n\n".join(out)


def question_summary(plan: dict, lang: str) -> str:
    qs = "\n".join(f"{k + 1}. {q['text']}" for k, q in enumerate(plan["questions"]))
    return f"{plan_lead(plan, lang)}\n\n{qs}"


def execution_summary(node: dict, lang: str) -> str:
    e = node["execution"]
    rows = "\n".join(
        f"| {s['step_index'] + 1} | {short(node['path']['steps'][s['step_index']]['description'])} | {code(lang, s['status'])} | "
        f"{max(len(s['cells']) - 1, 0)} | {len(s['deviations'])} | {sum(len(c['figures']) for c in s['cells'][-1:])} |"
        for s in e["steps"])
    skipped = len(node["path"]["steps"]) - len(e["steps"])
    return (f"**{lbl(lang, 'exec.status')}** `{code(lang, e['status'])}`"
            + (f" ({skipped} {t(lang, 'exec.not_run')})" if skipped else "")
            + f"\n\n{t(lang, 'exec.table')}\n|---|---|---|---|---|---|\n{rows}\n\n{t(lang, 'exec.read_first')}")


def interpretation_summary(node: dict, lang: str) -> str:
    i = node["interpretation"]
    findings = ("\n".join(f"- {f['statement']} *({code(lang, f['confidence'])})*" for f in i["findings"])
                or "- " + t(lang, "brief.none"))
    issues = "\n".join(f"- {x['problem']}" for x in i["issues"])
    concerns = "\n".join(f"- {a['assumption'] or a['note']} *({code(lang, a['status'])})*" for a in i["assumption_checks"]
                         if a["status"] in ("concern", "fails"))
    return ((f"{i['headline']}\n\n" if i["headline"] else "")
            + f"**{lbl(lang, 'interp.verdict')}** `{code(lang, i['verdict'])}`\n\n**{lbl(lang, 'interp.findings')}**\n{findings}\n\n"
            + (f"**{lbl(lang, 'interp.issues')}**\n{issues}\n\n" if issues else "")
            + (f"**{lbl(lang, 'interp.concerns')}**\n{concerns}\n\n" if concerns else "")
            + f"**{lbl(lang, 'interp.recommends')}** {first_sentences(i['recommendation_for_planner'], 2)}")


def brief_md(brief: dict, lang: str) -> str:
    return t(lang, "brief.intro") + "\n\n" + render_brief(brief, lang)


def plan_md(plan: dict, nodes: dict, lang: str, fence: str) -> str:
    out = ([f"**{lbl(lang, 'plan.phase')}** {code(lang, plan['phase'])}\n"] if plan.get("phase") else []) + [
        f"**{lbl(lang, 'plan.situation')}** {plan['situation']}\n",
        f"**{lbl(lang, 'plan.decision')}** `{code(lang, plan['decision'])}`\n",
        f"**{lbl(lang, 'plan.rationale')}** {plan['rationale']}\n"]
    if plan["decision"] == "complete":
        out.append(f"> {t(lang, 'plan.finish')}\n")
    if plan["paths"]:
        out.append(f"**{lbl(lang, 'plan.branches_from')}** `{plan['parent_node']}`\n")
    for i, path in enumerate(plan["paths"]):
        out.append(f"## {t(lang, 'plan.path', i=i, title=path['title'])}\n\n*{lbl(lang, 'plan.purpose')}* {path['purpose']}\n")
        for j, s in enumerate(path["steps"]):
            out.append(f"{j + 1}. **{s['description']}**  \n   {lbl(lang, 'plan.method')} {s['method']}  \n"
                       f"   {lbl(lang, 'plan.expected')} {s['expected_output']}")
            if s.get("suggested_code"):
                out.append(f"\n   ```{fence}\n{indent(s['suggested_code'])}\n   ```")
        out.append(f"\n*{lbl(lang, 'plan.evaluate')}* {path['evaluate_at']}\n")
        out.append(f"*{lbl(lang, 'plan.criteria')}*\n" + "\n".join(f"- {c}" for c in path["success_criteria"]))
        if path.get("assumptions_to_check"):
            out.append(f"\n*{lbl(lang, 'plan.assumptions')}*\n" + "\n".join(f"- {a}" for a in path["assumptions_to_check"]))
        out.append("")
    out.append(f"## {t(lang, 'plan.so_far')}\n\n" + render_tree(nodes, lang))
    return "\n".join(out)


def node_dir(run: Path, node: dict) -> Path:
    return run / (node["id"] if node["runs"] <= 1 else f"{node['id']}-run{node['runs']}")


def script_name(fence: str) -> str:
    return "analysis.R" if fence == "r" else "analysis.py"


def execution_md(node: dict, run: Path, lang: str, fence: str) -> str:
    e = node["execution"]
    done = sum(s["status"] == "done" for s in e["steps"])
    out = [f"**{lbl(lang, 'exec.path')}** {node['path']['title']}  \n**{lbl(lang, 'exec.status')}** `{code(lang, e['status'])}` "
           f"({t(lang, 'exec.steps_done', done=done, total=len(node['path']['steps']))})\n"]
    if node["runs"] > 1:
        out.append(f"> {t(lang, 'exec.rerun', run=node['runs'])}\n")
    deviations = [(s["step_index"], d) for s in e["steps"] for d in s["deviations"]]
    if deviations:
        out.append(f"## {t(lang, 'exec.departures')}\n\n" + "\n".join(f"- {i + 1}: {d}" for i, d in deviations) + "\n")
    for s in e["steps"]:
        planned = node["path"]["steps"][s["step_index"]]
        out.append(f"## {t(lang, 'exec.step', i=s['step_index'] + 1, description=planned['description'])} — "
                   f"`{code(lang, s['status'])}`\n\n*{lbl(lang, 'exec.planned')}* {planned['method']}\n")
        if len(s["cells"]) > 1:
            out.append(f"*{t(lang, 'exec.fixed', n=len(s['cells']) - 1)}*\n")
        if s["cells"]:
            c = s["cells"][-1]
            out.append(f"```{fence}\n{c['code'].strip()}\n```\n\n**{t(lang, 'exec.output')}**\n\n"
                       f"```\n{c['stdout'].strip() or t(lang, 'exec.nothing')}\n```")
            if c.get("error"):
                out.append(f"\n**{t(lang, 'exec.error')}**\n\n```\n{c['error'].strip()}\n```")
            for f in c["figures"]:
                out.append(f"\n![{Path(f).name}]({rel(f, run / 'handoffs')})")
        out.append("")
    skipped = len(node["path"]["steps"]) - len(e["steps"])
    if skipped:
        out.append(f"*{t(lang, 'exec.skipped', n=skipped)}*")
    out.append(f"\n{lbl(lang, 'exec.script')} `{rel(node_dir(run, node) / script_name(fence), run)}`")
    return "\n".join(out)


def interpretation_md(node: dict, lang: str) -> str:
    i = node["interpretation"]
    out = [f"**{lbl(lang, 'interp.path')}** {node['path']['title']}  \n**{lbl(lang, 'interp.verdict')}** "
           f"`{code(lang, i['verdict'])}`\n", f"**{t(lang, 'interp.adherence')}** {i['plan_adherence']}\n"]
    if i["assumption_checks"]:
        out.append(f"## {t(lang, 'interp.assumptions')}\n\n" + "\n".join(
            "- " + (f"**{a['assumption']}** " if a["assumption"] else "") + f"`{code(lang, a['status'])}`"
            + (f": {a['note']}" if a["note"] else "") for a in i["assumption_checks"]) + "\n")
    if i["findings"]:
        out.append(f"## {t(lang, 'interp.findings')}\n")
        for f in i["findings"]:
            out.append(f"- **{f['statement']}** ({t(lang, 'interp.confidence', level=code(lang, f['confidence']))})  \n"
                       f"  {lbl(lang, 'interp.evidence')} {f['evidence']}"
                       + "".join(f"  \n  {lbl(lang, 'interp.caveat')} {c}" for c in f["caveats"])
                       + (f"  \n  {lbl(lang, 'interp.figures')} {', '.join(f['figures'])}" if f["figures"] else ""))
    if i["issues"]:
        out.append(f"\n## {t(lang, 'interp.issues')}\n\n" + "\n".join(
            f"- **{x['problem']}**" + (f"  \n  {lbl(lang, 'interp.evidence')} {x['evidence']}" if x["evidence"] else "")
            + (f"  \n  {lbl(lang, 'interp.fix')} {x['proposed_fix']}" if x["proposed_fix"] else "") for x in i["issues"]))
    out.append(f"\n## {t(lang, 'interp.recommendation')}\n\n{i['recommendation_for_planner']}")
    return "\n".join(out)


def question_md(plan: dict, lang: str) -> str:
    out = [t(lang, "question.intro") + "\n"]
    for k, q in enumerate(plan["questions"]):
        out.append(f"{k + 1}. **{q['text']}**")
        if q["evidence"]:
            out.append(f"   {lbl(lang, 'question.evidence')} {q['evidence']}")
        for j, o in enumerate(q["options"]):
            out.append(f"   - {o}" + (f" *({t(lang, 'question.recommended')})*" if j == q.get("recommended") else ""))
        out.append("")
    out.append(f"*{lbl(lang, 'question.why')}* {plan['rationale']}")
    return "\n".join(out)


def answers_text(plan: dict, feedback: str, answers: dict[str, str], lang: str) -> str:
    if not answers:
        return p(lang, "ctx.qa", q="\n".join(q["text"] for q in plan["questions"]),
                 a=feedback.strip() or p(lang, "ctx.no_answer"))
    out = [p(lang, "ctx.qa", q=q["text"], a=answers.get(q["id"], "").strip() or p(lang, "ctx.no_answer"))
           for q in plan["questions"]]
    if feedback.strip():
        out.append(p(lang, "ctx.extra", text=feedback.strip()))
    return "\n\n".join(out)


def write_handover(run: Path, state: dict, stage: str, key: str, title: str, markdown: str, summary: str) -> dict:
    """The hand-over document (summary first, then detail), and the review point waiting on it."""
    lang = lang_of(state)
    folder = run / "handoffs"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{key}.md"
    body = f"## {t(lang, 'glance')}\n\n{summary}\n\n---\n\n{markdown}" if summary else markdown
    path.write_text(f"# {title}\n\n{body}\n", encoding="utf-8")
    pending = {"stage": stage, "key": key, "title": title, "summary": summary or markdown, "file": str(path),
               "options": S.OPTIONS[stage], "help": t(lang, f"help.{stage}"), "show": show_for(state, stage),
               "ask": ask_for(state, stage)}
    state["pending"] = pending
    return pending


# =========================================================================== what the user sees and is asked in the chat


def ui(state: dict, key: str, **kw) -> str:
    """A label from the review interface, in the analysis language."""
    text = S.UI_LABELS.get(lang_of(state), {}).get(key) or S.UI_LABELS["en"][key]
    return text.format(**kw) if kw else text


def step_outputs(state: dict, node: dict) -> list[str]:
    """Each step's printed output and figures, as the user should see them in the conversation."""
    lang, out = lang_of(state), []
    for s in node["execution"]["steps"]:
        planned = node["path"]["steps"][s["step_index"]]
        out.append(f"**{t(lang, 'exec.step', i=s['step_index'] + 1, description=planned['description'])}** "
                   f"`{code(lang, s['status'])}`")
        out += [f"- {d}" for d in s["deviations"]]
        if s["cells"]:
            c = s["cells"][-1]
            text = (c["stdout"].strip() or t(lang, "exec.nothing"))[-S.MAX_VIEW_OUTPUT:]
            out.append(f"```\n{text}\n```")
            if c.get("error"):
                out.append(f"```\n{c['error'].strip()[-S.MAX_VIEW_OUTPUT:]}\n```")
            out += [f"FIGURE: {f}" for f in c["figures"]]
    skipped = len(node["path"]["steps"]) - len(node["execution"]["steps"])
    if skipped:
        out.append(f"*{t(lang, 'exec.skipped', n=skipped)}*")
    return out


def show_for(state: dict, stage: str) -> str:
    """What to put in front of the user besides the summary: the data, the outputs and the figures themselves."""
    lang = lang_of(state)
    if stage == "brief":
        return "\n\n".join(f"**{t(lang, 'r.dataset', name=d['name'], rows=d['n_rows'], cols=d['n_cols'])}**\n\n"
                           f"{t(lang, 'r.columns')}\n|---|---|---|---|---|\n"
                           + "\n".join(f"| {c['name']} | {c['dtype']} | {c['n_missing']} | {c['n_unique']} | {c['summary']} |"
                                       for c in d["columns"]) for d in state["brief"]["datasets"])
    if stage == "question":
        plan = state["plans"][-1]
        return "\n".join(f"{k + 1}. {q['text']}" + (f"\n   {lbl(lang, 'question.evidence')} {q['evidence']}" if q["evidence"] else "")
                         for k, q in enumerate(plan["questions"]))
    if stage == "execution":
        return "\n\n".join(step_outputs(state, state["nodes"][state["current"]]))
    if stage == "interpretation":
        node = state["nodes"][state["current"]]
        if "execution" not in state["review_points"]:  # the user has not seen the outputs yet
            return "\n\n".join(step_outputs(state, node))
        paths = {Path(f).name: f for s in node["execution"]["steps"] for c in s["cells"] for f in c["figures"]}
        cited = dict.fromkeys(f for x in node["interpretation"]["findings"] for f in x["figures"] if f in paths)
        return "\n".join(f"FIGURE: {paths[f]}" for f in cited)
    return ""


def option(label: str, description: str, command: str, comment: str = "") -> dict:
    """One choice: its button, what it does, the command it runs, and the comment it needs ('required', 'optional')."""
    return {"label": label, "description": description, "command": command, "comment": comment or "optional"}


def ask_for(state: dict, stage: str) -> list[dict]:
    """The review point's questions for the chat's question tool, in the analysis language."""
    lang = lang_of(state)
    A = ASK[lang]
    stop = option(ui(state, "bar.stop").rstrip("…. "), A["d_stop"], "review RUN stop")
    if stage == "brief":
        return [{"question": A["brief"], "header": A["h_brief"], "comment": ui(state, "brief.note.label"),
                 "options": [option(ui(state, "brief.approve"), A["d_brief"], "review RUN approve"), stop]}]
    if stage == "plan":
        plan = state["plans"][-1]
        if plan["decision"] == "complete":
            return [{"question": A["finish"], "header": A["h_plan"], "comment": ui(state, "plan.missing.label"),
                     "options": [option(ui(state, "plan.finish"), A["d_finish"], "review RUN approve"),
                                 option(ui(state, "plan.not_done"), A["d_not_done"], "review RUN revise", "required"),
                                 stop]}]
        n = len(plan["paths"])
        revise = option(ui(state, "plan.revise"), A["d_revise"], "review RUN revise", "required")
        if n == 1:
            return [{"question": A["plan"], "header": A["h_plan"], "comment": ui(state, "plan.change.label"),
                     "options": [option(ui(state, "plan.approve"), A["d_plan"], "review RUN approve"), revise, stop]}]
        return [{"question": A["plan"], "header": A["h_plan"], "comment": ui(state, "plan.change.label"),
                 "options": [option(ui(state, "plan.approve_all", n=n), A["d_plan"], "review RUN approve"),
                             option(A["some"], A["d_some"], "ask the follow-up question"), revise, stop]},
                {"question": ui(state, "plan.paths") + " ?" if lang == "fr" else ui(state, "plan.paths") + "?",
                 "header": A["h_paths"], "multiSelect": True, "follow_up_for": A["some"],
                 "options": [option(A["path"].format(i=i), path["title"], str(i)) for i, path in enumerate(plan["paths"])],
                 "after": "Run review RUN approve --paths followed by the commands of every chosen path, e.g. --paths 0 2"}]
    if stage == "question":
        out = []
        for q in state["plans"][-1]["questions"]:
            order = list(range(len(q["options"])))
            if q.get("recommended") is not None and 0 <= q["recommended"] < len(order):
                order.insert(0, order.pop(q["recommended"]))
            opts = [option(q["options"][j] + (f" ({ui(state, 'q.recommended')})" if j == q.get("recommended") else ""),
                           q["evidence"] if j == order[0] and q["evidence"] else "",
                           f'--answer {q["id"]}="{q["options"][j]}"') for j in order]
            out.append({"question": q["text"], "header": q["id"], "comment": A["d_own"], "options": opts})
        out[-1]["after"] = (f"Run review RUN approve with one --answer per question (their own words when they wrote "
                            f"their own), and their note as --feedback: {ui(state, 'q.extra.label')}")
        return out
    if stage == "execution":
        return [{"question": A["execution"], "header": A["h_execution"], "comment": ui(state, "exec.note.label"),
                 "options": [option(ui(state, "exec.approve"), A["d_exec"], "review RUN approve"),
                             option(ui(state, "exec.rerun"), A["d_rerun"], "review RUN revise", "required"), stop]}]
    if stage == "interpretation":
        verdict = state["nodes"][state["current"]]["interpretation"]["verdict"]
        others = [v for v in S.VERDICTS if v != verdict]
        return [{"question": A["interpretation"], "header": A["h_interpretation"], "comment": ui(state, "interp.note.label"),
                 "options": [option(ui(state, "interp.approve_v", v=ui(state, f"vname.{verdict}")), A["d_interp"],
                                    "review RUN approve"),
                             option(ui(state, "interp.override_open").rstrip("…. "), A["d_override"],
                                    "ask the follow-up question", "required"),
                             option(ui(state, "interp.reinterpret"), A["d_reinterpret"], "review RUN revise", "required"),
                             stop]},
                {"question": ui(state, "interp.override_to") + (" ?" if lang == "fr" else "?"), "header": A["h_verdict"],
                 "follow_up_for": ui(state, "interp.override_open").rstrip("…. "),
                 "comment": ui(state, "interp.reason.label"),
                 "options": [option(ui(state, f"vname.{v}"), ui(state, f"vdesc.{v}"), f"review RUN override --verdict {v}",
                                    "required") for v in others]}]
    return []


# =========================================================================== flow (analyst.graph)


def reviewed(state: dict, stage: str) -> bool:
    return stage == "question" or stage in state["review_points"]


def hand_over(run: Path, state: dict, stage: str, key: str, title: str, markdown: str, summary: str) -> None:
    """Write the document; if this review point is switched off, approve it straight away (as the app does)."""
    write_handover(run, state, stage, key, title, markdown, summary)
    if not reviewed(state, stage):
        apply_review(run, state, "approve", "", None, None, {})


def start_next_node(state: dict) -> None:
    """Take the next queued node to the executor, or go back to the planner."""
    if state["queue"]:
        node = state["nodes"][state["queue"].pop(0)]
        node["runs"] += 1
        node["execution"] = None
        node["_steps"], node["_attempts"], node["_changes"], node["_fit"] = [], [], [], None
        state["current"], state["next"] = node["id"], "execute"
    else:
        state["current"], state["next"] = None, "plan"


def stop(state: dict, stage: str, feedback: str) -> None:
    state["status"], state["next"] = "stopped", "report"
    state["user_log"].append(note(stage, "stop", feedback))


def apply_review(run: Path, state: dict, action: str, feedback: str, paths: list[int] | None, verdict: str | None,
                 answers: dict[str, str]) -> None:
    pending = state.get("pending")
    if not pending:
        raise Fail(t(lang_of(state), "err.nothing_waiting"))
    stage, lang = pending["stage"], lang_of(state)
    if action not in S.OPTIONS[stage]:
        raise Fail(t(lang, "err.action", action=action, stage=stage) + f" Choose one of: {', '.join(S.OPTIONS[stage])}.")
    if action == "revise" and not feedback.strip():
        raise Fail(t(lang, "err.say_change"))
    state["pending"] = None
    if action == "stop":
        return stop(state, stage, feedback)
    log = note(stage, action, feedback)

    if stage == "brief":
        state["user_log"].append(log)
        if feedback.strip():
            state["brief"]["context"].append({"kind": "note", "source": p(lang, "ctx.brief_review"), "content": feedback})
        state["next"] = "plan"

    elif stage == "plan":
        plan, round_ = state["plans"][-1], state["round"]
        state["user_log"].append(log)
        if action == "revise":
            state["plan_feedback"], state["next"] = feedback, "plan"
            return
        if plan["decision"] == "complete":
            state["status"], state["next"] = "complete", "report"
            return
        chosen = paths if paths is not None else range(len(plan["paths"]))
        for i in chosen:
            if not 0 <= i < len(plan["paths"]):
                raise Fail(f"There is no path {i}; the plan has paths 0 to {len(plan['paths']) - 1}.")
            node_id = f"n{round_}{chr(ord('a') + i)}"
            state["nodes"][node_id] = {"id": node_id, "parent": plan["parent_node"], "path": plan["paths"][i],
                                       "execution": None, "interpretation": None,
                                       "user_notes": [log] if feedback.strip() else [], "user_verdict": None,
                                       "runs": 0, "interpretations": 0}
            state["queue"].append(node_id)
        if not state["queue"]:  # approved but selected nothing: ask the planner again
            state["plan_feedback"], state["next"] = feedback or p(lang, "plan.none_selected"), "plan"
            return
        start_next_node(state)

    elif stage == "question":
        plan = state["plans"][-1]
        if not answers and not feedback.strip():
            raise Fail(t(lang, "err.answer"))
        text = answers_text(plan, feedback, answers, lang)
        state["brief"]["context"].append({"kind": "note", "source": p(lang, "ctx.answer"), "content": text})
        state["user_log"].append(note("question", action, text))
        state["status"], state["next"] = "running", "plan"

    elif stage == "execution":
        node = state["nodes"][state["current"]]
        state["user_log"].append(log)
        if feedback.strip() or action == "revise":
            node["user_notes"].append(log)
        if action == "revise":
            state["queue"].insert(0, node["id"])
            start_next_node(state)
        else:
            state["next"] = "interpret"

    elif stage == "interpretation":
        node = state["nodes"][state["current"]]
        state["user_log"].append(log)
        if feedback.strip():
            node["user_notes"].append(log)
        if action == "revise":
            state["next"] = "interpret"
            return
        if action == "override":
            if verdict not in S.VERDICTS:
                raise Fail(t(lang, "err.choose_verdict") + f" One of: {', '.join(S.VERDICTS)}.")
            node["user_verdict"] = verdict
        start_next_node(state)


# =========================================================================== kernels (analyst.kernel, analyst.rkernel)


def rscript() -> str:
    configured = os.environ.get("ANALYST_RSCRIPT")
    if configured:
        return configured
    found = shutil.which("Rscript")
    if found:
        return found
    base = os.environ.get("ProgramFiles", r"C:\Program Files")
    candidates = sorted(Path(base, "R").glob("R-*/bin/Rscript.exe"), key=lambda x: x.parent.parent.name)
    if candidates:
        return str(candidates[-1])
    raise Fail("Rscript not found: R is not installed here (or set ANALYST_RSCRIPT to the Rscript executable). "
               "Use Python for this analysis, or install R.")


def r_library() -> str:
    """The R library the analysis uses: ANALYST_R_LIBRARY, else R's first library path."""
    configured = os.environ.get("ANALYST_R_LIBRARY")
    if configured:
        return str(Path(configured).resolve())
    out = subprocess.run([rscript(), "--vanilla", "-e", "cat(.libPaths()[1])"], capture_output=True, text=True,
                         timeout=120)
    return out.stdout.strip()


class Kernel:
    """One worker process (the app's Python or R worker, verbatim); a cell's state comes from replaying cells."""

    def __init__(self, code_language: str, workdir: Path, timeout: float, r_lib: str = ""):
        self.code_language, self.workdir, self.timeout, self.r_lib = code_language, workdir.resolve(), timeout, r_lib
        self.figdir = self.workdir / "_figures"
        shutil.rmtree(self.figdir, ignore_errors=True)
        self.figdir.mkdir(parents=True)
        if code_language == "r":
            worker = self.workdir / "_worker.R"
            worker.write_text(S.R_WORKER, encoding="utf-8")
            lib = r_lib
            env = dict(os.environ)
            env.update(R_LIBS=lib, R_LIBS_USER=lib, R_LIBS_SITE="", TZ=S.R_SETTINGS.get("timezone", "GMT"),
                       LC_TIME=S.R_SETTINGS.get("locale_time", "C"), LANGUAGE="en")
            cmd = [rscript(), "--vanilla", str(worker), self.figdir.as_posix(), Path(lib).as_posix() if lib else ""]
        else:
            worker = self.workdir / "_worker.py"
            worker.write_text(S.PY_WORKER, encoding="utf-8")
            env = None
            cmd = [sys.executable, *(["-P"] if sys.version_info >= (3, 11) else []), "-u", str(worker), str(self.figdir)]
        self._stderr = open(self.workdir / "_kernel_stderr.log", "a", encoding="utf-8")
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self._stderr, text=True,
                                     encoding="utf-8", cwd=self.workdir, env=env)
        if self._readline(S.STARTUP_TIMEOUT) is None:
            self.close()
            raise Fail(f"The {code_language} session failed to start; see {self.workdir / '_kernel_stderr.log'}")

    def send(self, code_: str, capture: bool) -> dict | None:
        self.proc.stdin.write(json.dumps({"code": code_, "capture_figures": capture}) + "\n")
        self.proc.stdin.flush()
        return self._readline(self.timeout)

    def _readline(self, timeout: float) -> dict | None:
        out: list[str] = []
        reader = threading.Thread(target=lambda: out.append(self.proc.stdout.readline()), daemon=True)
        reader.start()
        reader.join(timeout)
        return json.loads(out[0]) if out and out[0] else None

    def close(self) -> None:
        if self.proc.poll() is None:
            self.proc.kill()
            self.proc.wait()
        self._stderr.close()
        shutil.rmtree(self.figdir, ignore_errors=True)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def cell_check(fence: str):
    if fence != "r":
        return None
    import codecheck
    return codecheck.RPackageCheck(S.R_ALLOWED, codecheck.R_ALTERNATIVES)


def parent_cells(state: dict, parent: str) -> list[str]:
    if parent == "root":
        return [d["load_code"] for d in state["brief"]["datasets"]]
    return list(state["nodes"][parent]["execution"]["cells"])


def node_cells(state: dict, node: dict) -> list[str]:
    """The cells that define the node's session so far: the parent's, then this run's cells that worked."""
    done = [c["code"] for s in node["_steps"] for c in s["cells"] if c.get("error") is None]
    return parent_cells(state, node["parent"]) + done


def run_code(state: dict, run: Path, node: dict, code_: str, capture: bool = True) -> dict:
    """Run one cell after replaying the node's session; figures are numbered across the node's run, as in the app."""
    fence = fence_of(state)
    check = cell_check(fence)
    refusal = check(code_) if check else None
    if refusal:
        return {"code": code_, "stdout": "", "error": refusal, "figures": []}
    workdir = node_dir(run, node)
    workdir.mkdir(parents=True, exist_ok=True)
    with Kernel(fence, workdir, state["settings"]["cell_timeout"], state["settings"].get("r_library", "")) as k:
        for prior in node_cells(state, node):
            reply = k.send(prior, False)
            if reply is None or reply["error"]:
                raise Fail("Replaying the earlier cells of this node failed:\n" + prior[:500] + "\n"
                           + ((reply or {}).get("error") or "timed out"))
        reply = k.send(code_, capture)
        if reply is None:
            return {"code": code_, "stdout": "", "error": f"Cell timed out after {k.timeout}s or the kernel died.",
                    "figures": []}
        made = sorted(Path(f) for f in reply["figures"])
        offset = sum(len(c["figures"]) for s in node["_steps"] for c in s["cells"]) + sum(
            len(c["figures"]) for c in node["_attempts"])
        figures = []
        for i, f in enumerate(made):
            dest = workdir / f"fig_{offset + i + 1:03d}.png"
            shutil.move(str(f), dest)
            figures.append(str(dest))
    stdout = reply["stdout"]
    if len(stdout) > S.MAX_STDOUT:
        stdout = stdout[:S.MAX_STDOUT] + f"\n... [truncated {len(stdout) - S.MAX_STDOUT} chars]"
    return {"code": code_, "stdout": stdout, "error": reply["error"], "figures": figures}


def script_text(fence: str, cells: list[str]) -> str:
    header = S.R_HEADER if fence == "r" else S.PY_HEADER
    return header + "\n\n".join(f"# %% cell {i + 1}\n{c}" for i, c in enumerate(cells)) + "\n"


# =========================================================================== phases


def current_node(state: dict, phase: str) -> dict:
    if state.get("pending"):
        raise Fail(f"The {state['pending']['stage']} review point is waiting for the user ({state['pending']['file']}). "
                   "Show it and wait for their answer, then run `review`.")
    if state["next"] != phase:
        raise Fail(f"Now is not the {phase} phase: {describe_next(state)}")
    return state["nodes"][state["current"]]


def end_step(state: dict, run: Path, node: dict, status: str, deviations: list[str]) -> None:
    index = len(node["_steps"])
    node["_steps"].append({"step_index": index, "cells": node["_attempts"], "status": status,
                           "deviations": node["_changes"] + deviations})
    node["_attempts"], node["_changes"], node["_fit"] = [], [], None
    if status == "failed" or len(node["_steps"]) == len(node["path"]["steps"]):
        finish_execution(state, run, node)


def finish_execution(state: dict, run: Path, node: dict) -> None:
    fence, lang = fence_of(state), lang_of(state)
    steps = node.pop("_steps")
    for k in ("_attempts", "_changes", "_fit"):
        node.pop(k, None)
    cells = parent_cells(state, node["parent"]) + [c["code"] for s in steps for c in s["cells"] if c.get("error") is None]
    inspect = S.INSPECT_R if fence == "r" else S.INSPECT_PY
    workdir = node_dir(run, node)
    with Kernel(fence, workdir, state["settings"]["cell_timeout"], state["settings"].get("r_library", "")) as k:
        for c in cells:
            k.send(c, False)
        reply = k.send(inspect, False) or {"stdout": ""}
    (workdir / script_name(fence)).write_text(script_text(fence, cells), encoding="utf-8")
    n_done = sum(s["status"] == "done" for s in steps)
    status = "done" if n_done == len(node["path"]["steps"]) else ("failed" if n_done == 0 else "partial")
    node["execution"] = {"node_id": node["id"], "path": node["path"], "steps": steps, "status": status, "cells": cells,
                         "variables": reply["stdout"].strip()}
    state["next"] = "interpret"
    hand_over(run, state, "execution", f"{node['id']}_execution_{node['runs']}",
              t(lang, "title.execution", node=node["id"], path=node["path"]["title"]),
              execution_md(node, run, lang, fence), execution_summary(node, lang))


# =========================================================================== prompts (the agents' per-call input)


def planner_prompt(state: dict) -> str:
    lang = lang_of(state)
    rejected = state["plans"][-1] if state.get("plan_feedback") is not None and state["plans"] else None
    revision = ""
    if rejected is not None:
        revision = p(lang, "plan.revision", proposal=json.dumps(rejected, indent=2, ensure_ascii=False),
                     feedback=state["plan_feedback"] or p(lang, "plan.no_feedback")) + "\n\n"
    round_, max_rounds = state["round"], state["settings"]["max_rounds"]
    text = (f"{p(lang, 'plan.brief')}\n\n{render_brief(state['brief'], lang)}\n\n"
            f"{p(lang, 'plan.state')}\n\n{render_tree(public_nodes(state), lang)}\n\n"
            + revision
            + p(lang, "plan.budget", round=round_ + 1, max=max_rounds)
            + (p(lang, "plan.last_round") + "\n" if round_ + 1 >= max_rounds else "\n")
            + "\n" + p(lang, "plan.task"))
    missing = state["settings"].get("r_missing") or []
    if missing:
        text += "\n\n" + EXTRA[lang]["r_missing"].format(names=", ".join(missing))
    return text


def executor_prompt(state: dict, run: Path) -> str:
    lang, fence = lang_of(state), fence_of(state)
    node = current_node(state, "execute")
    index = len(node["_steps"])
    if node["_fit"]:
        step, cell = node["path"]["steps"][index], node["_attempts"][-1]
        return p(lang, "exec.review", i=index + 1, description=step["description"], method=step["method"],
                 code=cell["code"], out=cell["stdout"][-8000:], hits=", ".join(node["_fit"]), fence=fence)
    user = render_user_notes(node["user_notes"], ("plan", "execution"), lang)
    if user:
        user += p(lang, "exec.user_plan") + "\n\n"
        if node["runs"] > 1:
            user += p(lang, "exec.rerun", run=node["runs"]) + "\n\n"
    history = "\n\n".join(summarise_step(s, lang, fence) for s in node["_steps"]) or p(lang, "exec.none_yet")
    text = (f"{p(lang, 'exec.path')}\n\n{render_path(node['path'], lang, fence)}\n\n{user}"
            f"{p(lang, 'exec.done')}\n\n{history}\n\n" + p(lang, "exec.task", i=index + 1))
    for i, c in enumerate(node["_attempts"]):
        text += "\n\n" + failed_attempt(lang, fence, i, c)
    return text


def failed_attempt(lang: str, fence: str, i: int, cell: dict) -> str:
    return p(lang, "exec.failed", i=i + 1, code=cell["code"], out=cell["stdout"][-3000:], error=cell["error"], fence=fence)


def public_nodes(state: dict) -> dict:
    """Nodes as the agents see them (without the executor's work in progress)."""
    return {k: {x: y for x, y in v.items() if not x.startswith("_")} for k, v in state["nodes"].items()}


def interpreter_prompt(state: dict) -> str:
    lang, fence = lang_of(state), fence_of(state)
    node = current_node(state, "interpret")
    prior = {k: v for k, v in public_nodes(state).items() if k != node["id"]}
    record = node["execution"]
    text = (f"{p(lang, 'interp.brief')}\n\n{render_brief(state['brief'], lang)}\n\n"
            f"{p(lang, 'interp.earlier')}\n\n{render_tree(prior, lang)}\n\n"
            f"{p(lang, 'interp.plan', node=node['id'])}\n\n{render_path(record['path'], lang, fence)}\n\n"
            f"{p(lang, 'interp.execution', status=record['status'])}\n\n{render_execution(record, lang, fence)}\n\n"
            + render_user_notes(node["user_notes"], ("execution", "interpretation"), lang)
            + p(lang, "interp.task"))
    figures = figures_of(record)[:S.MAX_FIGURES]
    if figures:
        text += f"\n\n{EXTRA[lang]['figures']}\n" + "\n".join(f"- {f}" for f in figures)
    return text


def report_prompt(state: dict) -> str:
    lang = lang_of(state)
    if state["next"] != "report":
        raise Fail(f"The analysis has not finished: {describe_next(state)}")
    return (f"{p(lang, 'interp.brief')}\n\n{render_brief(state['brief'], lang)}\n\n"
            f"{p(lang, 'report.results')}\n\n{render_tree(public_nodes(state), lang)}\n\n"
            + p(lang, "report.task", status=state["status"]))


# =========================================================================== what next


def refs(state: dict) -> str:
    return f"references/{lang_of(state)}-{fence_of(state)}/"


def describe_next(state: dict) -> str:
    """The next action, naming the run folder RUN in the commands."""
    pending, run = state.get("pending"), state["settings"]["run"]
    cmd = "session.py {} RUN"
    if pending:
        return (f"REVIEW POINT `{pending['stage']}` is waiting for the user: {pending['file']}. Show them its At a "
                "glance section and everything under SHOW THE USER (figures as images), ask the questions under ASK "
                "THE USER with your question tool, and wait for their answer. Then run the command their choice maps "
                f"to, with their comment as --feedback, where RUN is {run}.")
    if state["next"] == "done":
        return f"The analysis is finished. The report is {Path(run) / 'report.md'}."
    return next_agent(state, cmd) + f"\n(RUN is {run})"


def next_agent(state: dict, cmd: str) -> str:
    nxt = state["next"]
    if nxt == "report":
        return (f"REPORT (status {state['status']}): read {refs(state)}report.md, run " + cmd.format("prompt") + " report, "
                "write the report as Markdown to a file, then " + cmd.format("report") + " <file>.")
    if nxt == "plan":
        if state["round"] >= state["settings"]["max_rounds"]:
            return "The planning budget is used up: " + cmd.format("next") + " moves to the report."
        return (f"PLANNER, round {state['round'] + 1}: read {refs(state)}planner.md if it is not in your context, run "
                + cmd.format("prompt") + " planner, write the Plan JSON to a file, then " + cmd.format("plan") + " <file>.")
    node = state["nodes"][state["current"]]
    if nxt == "execute":
        i = len(node["_steps"])
        if node["_fit"]:
            return (f"EXECUTOR, node {node['id']} step {i + 1}: the output shows fit-failure signs; run "
                    + cmd.format("prompt") + " executor and answer with " + cmd.format("fit") + " achieved|failed --notes ...")
        attempt = f" (attempt {len(node['_attempts']) + 1})" if node["_attempts"] else ""
        return (f"EXECUTOR, node {node['id']} step {i + 1} of {len(node['path']['steps'])}{attempt}: read "
                f"{refs(state)}executor.md if it is not in your context, run " + cmd.format("prompt") + " executor, "
                "write that step's code to a file, then " + cmd.format("run") + " <file> [--change ...], or "
                + cmd.format("fail") + " --reason ... if it cannot be done as written.")
    return (f"INTERPRETER, node {node['id']}: read {refs(state)}interpreter.md if it is not in your context, run "
            + cmd.format("prompt") + " interpreter, look at every figure it lists, write the Interpretation JSON to a "
            "file, then " + cmd.format("interpret") + " <file>.")


def show_pending(state: dict) -> str:
    pending = state.get("pending")
    if not pending:
        return ""
    out = (f"\n=== REVIEW POINT: {pending['stage']} ===\nDocument: {pending['file']}\n\n# {pending['title']}\n\n"
           f"## {t(lang_of(state), 'glance')}\n\n{pending['summary']}\n")
    if pending.get("show"):
        out += f"\n=== SHOW THE USER (FIGURE lines are images to display) ===\n\n{pending['show']}\n"
    if pending.get("ask"):
        out += ("\n=== ASK THE USER (with the question tool; RUN is the run folder) ===\n\n"
                + json.dumps(pending["ask"], indent=1, ensure_ascii=False) + "\n")
    return out


def advance_budget(state: dict) -> None:
    if state["next"] == "plan" and not state.get("pending") and state["round"] >= state["settings"]["max_rounds"]:
        state["status"], state["next"] = "out_of_budget", "report"


# =========================================================================== commands


def cmd_check(a) -> str:
    lines = [f"Python {sys.version.split()[0]} ({sys.executable})"]
    for mod in ("pandas", "numpy", "scipy", "statsmodels", "matplotlib"):
        try:
            m = __import__(mod)
            lines.append(f"  {mod} {getattr(m, '__version__', '')}")
        except ImportError:
            lines.append(f"  {mod}: MISSING" + (" (needed)" if mod in ("pandas", "numpy", "matplotlib") else ""))
    try:
        exe = rscript()
    except Fail as e:
        lines.append(f"R: not available. {e}")
        return "\n".join(lines)
    version = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=60)
    lines.append(f"R: {exe} ({(version.stdout or version.stderr).splitlines()[0] if (version.stdout or version.stderr) else '?'})")
    if a.code_language == "r":
        lib = r_library()
        lines.append(f"  library: {lib}")
        missing = r_missing(lib)
        visible = [n for n in S.R_VISIBLE if n not in missing]
        lines.append(f"  R-Instat packages available: {len(visible)} of {len(S.R_VISIBLE)}")
        if missing:
            lines.append(f"  not installed: {', '.join(missing)}")
        if "jsonlite" in missing or not r_has(lib, "jsonlite"):
            lines.append("  jsonlite is MISSING: the R session needs it. Install it, or use Python.")
    return "\n".join(lines)


def r_installed(lib: str) -> set[str]:
    code_ = f".libPaths({json.dumps(Path(lib).as_posix())}); cat(rownames(installed.packages()), sep='\\n')" if lib \
        else "cat(rownames(installed.packages()), sep='\\n')"
    out = subprocess.run([rscript(), "--vanilla", "-e", code_], capture_output=True, text=True, timeout=300)
    return set(out.stdout.split())


def r_has(lib: str, name: str) -> bool:
    return name in r_installed(lib)


def r_missing(lib: str) -> list[str]:
    have = r_installed(lib)
    return [n for n in S.R_VISIBLE if n not in have]


def cmd_init(a) -> str:
    run = Path(a.run)
    if state_file(run).exists() and not a.force:
        raise Fail(f"{run} already holds an analysis. Use another folder, `session.py next {run}` to carry on, "
                   "or --force to start again there.")
    lang = a.language
    if lang not in ("en", "fr"):
        raise Fail(t("en", "err.language", lang=lang))
    settings = {"run": str(run), "language": lang, "max_rounds": a.max_rounds, "cell_timeout": S.DEFAULTS["cell_timeout"],
                "max_fix_attempts": S.DEFAULTS["max_fix_attempts"]}
    if a.code_language == "r":
        settings["r_library"] = r_library()
        settings["r_missing"] = r_missing(settings["r_library"])
        if "jsonlite" not in r_installed(settings["r_library"]):
            raise Fail("The R session needs the jsonlite package, which is not installed. Install it, or use Python.")
    for rp in a.review_points:
        if rp not in S.REVIEW_POINTS:
            raise Fail(f"Unknown review point {rp!r}; choose from {', '.join(S.REVIEW_POINTS)}.")
    run.mkdir(parents=True, exist_ok=True)
    brief = make_brief(a.goal, a.data, a.context_file, a.note, a.query, a.constraint, lang, a.code_language, run)
    state = {"settings": settings, "brief": brief, "nodes": {}, "queue": [], "current": None, "plans": [], "round": 0,
             "status": "running", "plan_feedback": None, "user_log": [], "review_points": list(a.review_points),
             "final_report": None, "next": "brief", "pending": None}
    hand_over(run, state, "brief", "00_brief", t(lang, "title.brief"), brief_md(brief, lang), brief_summary(brief, lang))
    advance_budget(state)
    save(run, state)
    return show_pending(state) or describe_next(state)


def cmd_next(a) -> str:
    run = Path(a.run)
    state = load(run)
    advance_budget(state)
    save(run, state)
    return show_pending(state) + "\n" + describe_next(state)


def cmd_prompt(a) -> str:
    run = Path(a.run)
    state = load(run)
    if state.get("pending"):
        raise Fail(describe_next(state))
    if a.agent == "planner":
        if state["next"] != "plan":
            raise Fail(f"Now is not the planning phase: {describe_next(state)}")
        return planner_prompt(state)
    if a.agent == "executor":
        return executor_prompt(state, run)
    if a.agent == "interpreter":
        return interpreter_prompt(state)
    return report_prompt(state)


def cmd_plan(a) -> str:
    run = Path(a.run)
    state = load(run)
    if state.get("pending") or state["next"] != "plan":
        raise Fail(describe_next(state))
    plan = read_model(a.file, "Plan")
    # The app's Plan check (state.Plan._decision_matches_contents), which a JSON schema cannot express.
    d = plan["decision"]
    cont, ask = d == "continue", d == "need_user_input"
    if cont and not plan["paths"]:
        raise Fail("decision is `continue` but `paths` is empty: propose at least one path, "
                   "or choose `complete` or `need_user_input`")
    if ask and not plan["questions"]:
        raise Fail("decision is `need_user_input` but `questions` is empty: ask at least one question, "
                   "or choose another decision")
    if plan["paths"] and not cont:
        raise Fail(f"decision is `{d}` but `paths` is not empty: paths are only for "
                   "`continue`; leave `paths` empty, or choose `continue`")
    if plan["questions"] and not ask:
        raise Fail(f"decision is `{d}` but `questions` is not empty: questions are only "
                   "for `need_user_input`; leave `questions` empty, or choose `need_user_input`")
    for i, q in enumerate(plan["questions"]):
        if not q["id"] or [x["id"] for x in plan["questions"]].index(q["id"]) != i:
            q["id"] = f"q{i + 1}"
    if plan["parent_node"] != "root":
        parent = state["nodes"].get(plan["parent_node"])
        if parent is None or parent.get("execution") is None:
            raise Fail(f"Parent node {plan['parent_node']!r} does not exist or was not executed.")
        if verdict_of(parent) == "abandon":
            raise Fail(f"Node {plan['parent_node']!r} was abandoned; branch from another node.")
    state["plans"].append(plan)
    state["round"] += 1
    state["plan_feedback"] = None
    lang, round_ = lang_of(state), state["round"]
    if plan["decision"] == "need_user_input":
        state["status"] = "need_user_input"
        hand_over(run, state, "question", f"r{round_:02d}_question", t(lang, "title.question"), question_md(plan, lang),
                  question_summary(plan, lang))
    else:
        state["status"] = "running"
        title = t(lang, "title.finish") if plan["decision"] == "complete" else t(lang, "title.plan", round=round_)
        hand_over(run, state, "plan", f"r{round_:02d}_plan", title, plan_md(plan, public_nodes(state), lang, fence_of(state)),
                  plan_summary(plan, lang))
    advance_budget(state)
    save(run, state)
    trace(run, state)
    return show_pending(state) or describe_next(state)


def cmd_run(a) -> str:
    run = Path(a.run)
    state = load(run)
    node = current_node(state, "execute")
    if node["_fit"]:
        raise Fail(describe_next(state))
    lang, fence = lang_of(state), fence_of(state)
    code_ = sys.stdin.read() if a.file == "-" else Path(a.file).read_text(encoding="utf-8")
    index = len(node["_steps"])
    node["_changes"] = list(a.change)
    result = run_code(state, run, node, code_)
    node["_attempts"].append(result)
    out = [f"=== node {node['id']}, step {index + 1}, attempt {len(node['_attempts'])} ==="]
    if result["error"]:
        attempts = len(node["_attempts"])
        if attempts > state["settings"]["max_fix_attempts"]:
            out.append(result["error"].strip())
            end_step(state, run, node, "failed", [p(lang, "exec.gave_up", n=attempts)])
            out.append(f"\nThe step failed after {attempts} attempts; the remaining steps are not run.")
        else:
            out.append(failed_attempt(lang, fence, attempts - 1, result))
    else:
        out.append(result["stdout"].rstrip() or "(nothing printed)")
        if result["figures"]:
            out.append("Figures: " + ", ".join(result["figures"]))
        hits = sorted({m.group(0) for m in FIT_WARNINGS.finditer(result["stdout"])})
        if hits:
            node["_fit"] = hits
            out.append("\nFIT CHECK: " + executor_prompt(state, run))
        else:
            end_step(state, run, node, "done", [])
    save(run, state)
    trace(run, state)
    return "\n".join(out) + "\n" + (show_pending(state) or "\n" + describe_next(state))


def cmd_fail(a) -> str:
    run = Path(a.run)
    state = load(run)
    node = current_node(state, "execute")
    if node["_fit"]:
        raise Fail(describe_next(state))
    node["_changes"] = list(a.change)
    end_step(state, run, node, "failed", [p(lang_of(state), "exec.not_achievable", notes=a.reason)])
    save(run, state)
    trace(run, state)
    return show_pending(state) or describe_next(state)


def cmd_fit(a) -> str:
    run = Path(a.run)
    state = load(run)
    node = current_node(state, "execute")
    if not node["_fit"]:
        raise Fail("No fit check is waiting. " + describe_next(state))
    if a.result == "achieved":
        end_step(state, run, node, "done", [])
    else:
        end_step(state, run, node, "failed", [p(lang_of(state), "exec.fit_failed", notes=a.notes)])
    save(run, state)
    trace(run, state)
    return show_pending(state) or describe_next(state)


def cmd_interpret(a) -> str:
    run = Path(a.run)
    state = load(run)
    node = current_node(state, "interpret")
    result = read_model(a.file, "Interpretation")
    result["node_id"] = node["id"]
    node["interpretation"] = result
    node["interpretations"] += 1
    lang = lang_of(state)
    state["next"] = "plan"  # until the review says otherwise
    hand_over(run, state, "interpretation", f"{node['id']}_interpretation_{node['interpretations']}",
              t(lang, "title.interpretation", node=node["id"], path=node["path"]["title"]), interpretation_md(node, lang),
              interpretation_summary(node, lang))
    advance_budget(state)
    save(run, state)
    trace(run, state)
    return show_pending(state) or describe_next(state)


def cmd_review(a) -> str:
    run = Path(a.run)
    state = load(run)
    answers = {}
    for item in a.answer:
        qid, sep, text = item.partition("=")
        if not sep:
            raise Fail(f"--answer takes id=text, e.g. --answer q1=\"Yes, merge them\" (got {item!r}).")
        answers[qid.strip()] = text
    apply_review(run, state, a.action, a.feedback, a.paths, a.verdict, answers)
    advance_budget(state)
    save(run, state)
    trace(run, state)
    return show_pending(state) or describe_next(state)


def cmd_points(a) -> str:
    run = Path(a.run)
    state = load(run)
    for rp in a.review_points:
        if rp not in S.REVIEW_POINTS:
            raise Fail(f"Unknown review point {rp!r}; choose from {', '.join(S.REVIEW_POINTS)}.")
    state["review_points"] = list(a.review_points)
    save(run, state)
    off = [rp for rp in S.REVIEW_POINTS if rp not in a.review_points]
    return (f"Review points on: {', '.join(a.review_points) or 'none'}" + (f"; off: {', '.join(off)}" if off else "")
            + ". Planner questions always wait for the user.")


def cmd_report(a) -> str:
    run = Path(a.run)
    state = load(run)
    if state.get("pending") or state["next"] != "report":
        raise Fail(describe_next(state))
    text = Path(a.file).read_text(encoding="utf-8")
    state["final_report"], state["next"] = text, "done"
    (run / "report.md").write_text(text, encoding="utf-8")
    save(run, state)
    trace(run, state)
    return f"Report saved: {run / 'report.md'}"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="session.py", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="command", required=True)
    c = sub.add_parser("check", help="what this computer can run")
    c.add_argument("--code-language", choices=["python", "r"], default="python")
    c = sub.add_parser("init", help="start an analysis: profile the data and write the brief")
    c.add_argument("run")
    c.add_argument("--goal", required=True)
    c.add_argument("--data", nargs="+", default=[])
    c.add_argument("--context-file", nargs="*", default=[])
    c.add_argument("--note", action="append", default=[])
    c.add_argument("--query", action="append", default=[], help="a question the user wants answered")
    c.add_argument("--constraint", action="append", default=[])
    c.add_argument("--language", default="en")
    c.add_argument("--code-language", choices=["python", "r"], default="python")
    c.add_argument("--review-points", nargs="*", default=list(S.REVIEW_POINTS))
    c.add_argument("--max-rounds", type=int, default=S.DEFAULTS["max_rounds"])
    c.add_argument("--force", action="store_true")
    sub.add_parser("next", help="where the analysis is, and what to do now").add_argument("run")
    c = sub.add_parser("points", help="switch review points on or off: list the ones to keep")
    c.add_argument("run")
    c.add_argument("review_points", nargs="*")
    c = sub.add_parser("prompt", help="the input for the next agent call")
    c.add_argument("run")
    c.add_argument("agent", choices=["planner", "executor", "interpreter", "report"])
    for name in ("plan", "interpret", "report"):
        c = sub.add_parser(name)
        c.add_argument("run")
        c.add_argument("file", help="a file, or - for stdin")
    c = sub.add_parser("run", help="run the current step's code")
    c.add_argument("run")
    c.add_argument("file", help="a file, or - for stdin")
    c.add_argument("--change", action="append", default=[], help="a fix to an obvious error in the instructions, and why")
    c = sub.add_parser("fail", help="the current step cannot be done as written")
    c.add_argument("run")
    c.add_argument("--reason", required=True)
    c.add_argument("--change", action="append", default=[])
    c = sub.add_parser("fit", help="answer the fit check")
    c.add_argument("run")
    c.add_argument("result", choices=["achieved", "failed"])
    c.add_argument("--notes", default="")
    c = sub.add_parser("review", help="the user's answer at a review point")
    c.add_argument("run")
    c.add_argument("action", choices=["approve", "revise", "override", "stop"])
    c.add_argument("--feedback", default="")
    c.add_argument("--paths", type=int, nargs="*", default=None, help="plan: 0-based paths to run (default all)")
    c.add_argument("--verdict", default=None)
    c.add_argument("--answer", action="append", default=[], help="question: id=answer")
    a = ap.parse_args(argv)
    handler = globals()[f"cmd_{a.command}"]
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    try:
        print(handler(a))
    except Fail as e:
        print(f"NOT DONE: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
