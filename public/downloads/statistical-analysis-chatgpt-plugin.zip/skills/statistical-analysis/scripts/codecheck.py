"""Checks run on each cell before it is executed (see `Kernel.check`).

A refused cell comes back to the executor as an ordinary error it can fix: it names the
package and, where there is an obvious one, an allowed alternative. This keeps the agents
inside a curated package set; it is not a security sandbox (the kernel's library path is
the other half of that).

`PackageCheck` holds what is common to every language: the allowlist, the message and the
suggestions. A language only says how to find the packages a cell uses (`find`). R has one
(`RPackageCheck`); a Python import check would subclass it the same way, finding imports
with `ast`, once there is a Python allowlist.
"""

from __future__ import annotations

import difflib
import re
from typing import Callable, Iterable

# Usual alternatives within R-Instat's set for packages agents tend to reach for that are not in it
# (many popular ones, such as tidyverse, emmeans, car and lmerTest, are: they come in as dependencies).
# A suggestion is only made if its package is in the allowlist.
R_ALTERNATIVES: dict[str, list[str]] = {
    "glmmTMB": ["lme4"],
    "broom.mixed": ["lme4", "broom"],
    "DHARMa": ["stats::residuals", "ggfortify (autoplot diagnostics)"],
    "MuMIn": ["stats::AIC"],
    "lsmeans": ["emmeans"],
    "margins": ["ggeffects", "emmeans", "prediction"],
    "marginaleffects": ["ggeffects", "emmeans", "prediction"],
    "effects": ["ggeffects", "visreg"],
    "geepack": ["lme4 (mixed models)", "sandwich (robust standard errors)"],
    "gee": ["lme4 (mixed models)", "sandwich (robust standard errors)"],
    "clubSandwich": ["sandwich", "lmtest"],
    "plm": ["lme4", "sandwich"],
    "AER": ["sandwich", "lmtest", "survival::survreg (tobit)"],
    "betareg": ["stats::glm (quasibinomial)"],
    "pscl": ["MASS::glm.nb"],
    "survminer": ["survival", "ggfortify (autoplot of survfit)"],
    "psych": ["Hmisc", "DescTools"],
    "pwr": ["stats::power.t.test", "Hmisc"],
    "tseries": ["stats", "trend"],
    "tsibble": ["zoo", "xts", "lubridate"],
    "fable": ["forecast", "stats::arima"],
    "prophet": ["forecast", "stats::arima"],
    "randomForest": ["rpart", "caret"],
    "xgboost": ["rpart", "caret"],
    "vegan": ["FactoMineR", "factoextra"],
    "ggstatsplot": ["ggplot2", "ggpubr"],
    "openxlsx": ["writexl", "readxl", "rio"],
    "kableExtra": ["print() of a data frame"],
    "flextable": ["print() of a data frame"],
}

R_INSTALLERS = re.compile(
    r"\b(install\.packages|update\.packages|remove\.packages|install_github|install_cran|install_url|"
    r"install_version|install_local|install_deps|pkg_install|pak)\s*\(")


class PackageCheck:
    """Refuses cells that use packages outside `allowed`."""

    def __init__(self, allowed: Iterable[str], alternatives: dict[str, list[str]] | None = None):
        self.allowed = frozenset(allowed)
        self._lower = {a.lower(): a for a in self.allowed}
        self.alternatives = alternatives or {}

    def find(self, code: str) -> tuple[list[str], list[str]]:
        """The packages the code uses, and any other problems found (as messages)."""
        raise NotImplementedError

    def __call__(self, code: str) -> str | None:
        used, problems = self.find(code)
        bad = list(dict.fromkeys(p for p in used if p not in self.allowed))
        lines = [self._explain(p) for p in bad] + problems
        if not lines:
            return None
        return ("Error: this cell was not run.\n" + "\n".join(f"- {line}" for line in lines)
                + "\nRewrite the cell using only the available packages.")

    def _explain(self, pkg: str) -> str:
        msg = f"Package '{pkg}' is not available: only R-Instat's curated packages (and their dependencies) can be used."
        hints = [h for h in self.alternatives.get(pkg, []) if h.split()[0].split("::")[0] in self.allowed]
        near = self._lower.get(pkg.lower()) or next(iter(difflib.get_close_matches(pkg, self.allowed, 1, 0.85)), None)
        if near and near != pkg:
            hints.insert(0, f"{near} (did you mean this?)")
        return msg + (f" Instead, try: {', '.join(hints)}." if hints else "")


# --------------------------------------------------------------------------- R

_NAME = r"[A-Za-z][A-Za-z0-9._]*"
_STRING = re.compile(r"""[rR](["'])(-*)[\[({](?:.|\n)*?[\])}]\2\1|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`[^`]*`""")
_LOADERS = re.compile(r"\b(library|require|requireNamespace|loadNamespace|attachNamespace)\s*\(([^()]*)")
_NAMESPACED = re.compile(rf"(?<![\w.])({_NAME})\s*:::?")


class RPackageCheck(PackageCheck):
    def find(self, code: str) -> tuple[list[str], list[str]]:
        masked, strings = _mask_r(code)
        used, problems = [], []
        if R_INSTALLERS.search(masked):
            problems.append("Installing packages is disabled: use the packages that are already installed.")
        for fn, args in _LOADERS.findall(masked):
            first = _first_arg(args)
            if not first:
                continue
            literal = re.fullmatch(r"__S(\d+)__", first)
            if literal:
                used.append(strings[int(literal.group(1))])
            elif re.search(r"character\.only\s*=\s*(TRUE|T)\b", args):
                problems.append(f"{fn}() is given the package through a variable: name the package directly, "
                                f"e.g. {fn}(dplyr), so the check can see it.")
            elif re.fullmatch(_NAME, first):
                used.append(first)
        used += _NAMESPACED.findall(masked)
        return used, problems


def _mask_r(code: str) -> tuple[str, list[str]]:
    """Code with comments removed and each string literal replaced by a placeholder `"__S<n>__"`."""
    strings: list[str] = []
    out, i = [], 0
    pattern = re.compile(_STRING.pattern + r"|#[^\n]*")
    for m in pattern.finditer(code):
        out.append(code[i:m.start()])
        tok = m.group(0)
        if tok.startswith("#"):
            pass
        elif tok.startswith("`"):
            out.append(tok)  # a backticked name, not a string
        else:
            if tok[0] in "rR":  # raw string r"(...)" or r"--[...]--"
                d = len(m.group(2))
                body = tok[3 + d:len(tok) - 2 - d]
            else:
                body = tok[1:-1]
            strings.append(body)
            out.append(f'"__S{len(strings) - 1}__"')
        i = m.end()
    out.append(code[i:])
    return "".join(out), strings


def _first_arg(args: str) -> str:
    """The package argument of library()/require()...: the first positional one, or `package=`."""
    parts = [a.strip() for a in args.split(",")]
    for a in parts:
        m = re.fullmatch(r"(package|pkg)\s*=\s*(.+)", a)
        if m:
            return m.group(2).strip().strip('"')
    first = parts[0] if parts else ""
    return "" if "=" in first else first.strip('"')


# --------------------------------------------------------------------------- per language


def check_for(code_language: str) -> Callable[[str], str | None] | None:
    """The cell check for a code language. Python has none yet (there is no Python allowlist)."""
    if code_language == "r":
        from analyst import rpackages
        return RPackageCheck(rpackages.allowlist(), R_ALTERNATIVES)
    return None
