"""Languages: everything the system says to the user, and everything it says to the agents.

Two settings are kept apart:
- the *analysis language* (per analysis, `AgentConfig.language`): the language the agents
  work in end to end. Their role texts and playbooks (`playbooks/<lang>/`), the per-call
  prompts (`PROMPTS` below) and the review documents (`STRINGS`) are all in it, so a French
  analysis is planned, reasoned and written in French;
- the *interface language* (per viewer, in the UI): buttons, labels and messages. Its strings
  live in `ui/static/i18n.json`; this module covers what the server itself produces.

JSON field names and coded values (decisions, verdicts, statuses) stay in English in every
language: they are the data format the code reads.
"""

from __future__ import annotations

LANGUAGES = {"en": "English", "fr": "Français"}
DEFAULT = "en"

STRINGS: dict[str, dict[str, str]] = {
    "en": {
        # review documents
        "glance": "At a glance",
        "brief.intro": "This is what the agents will work from. Check the goal says what you actually want, and "
                       "that the data profiles look right.",
        "brief.goal": "Goal", "brief.data": "Data", "brief.context": "Context items", "brief.none": "(none)",
        "brief.dataset": "`{name}`: {rows} rows x {cols} columns ({missing} columns with missing values)",
        "title.brief": "Brief", "title.plan": "Plan, round {round}", "title.finish": "Planner proposes to finish",
        "title.question": "The planner has a question", "title.execution": "Execution of {node}: {path}",
        "title.interpretation": "Interpretation of {node}: {path}", "title.report": "Final report",
        "plan.situation": "Planner's reading of the situation", "plan.decision": "Decision", "plan.rationale": "Rationale",
        "plan.finish": "The planner proposes to **finish** and write the report. Approve to finish, or revise to "
                       "say what is still missing.",
        "plan.branches_from": "Branches from", "plan.path": "Path {i}: {title}", "plan.purpose": "Purpose",
        "plan.method": "Method", "plan.expected": "Expected output", "plan.evaluate": "Evaluated at the end",
        "plan.criteria": "Success criteria", "plan.assumptions": "Assumptions to check",
        "plan.so_far": "Analysis so far", "plan.why": "Why these paths", "plan.situation_short": "Situation",
        "plan.branching": "Branching from `{parent}`:", "plan.table": "| # | path | steps | methods |",
        "plan.phase": "Phase",
        "exec.path": "Path", "exec.status": "Status", "exec.steps_done": "{done} of {total} steps done",
        "exec.rerun": "This is re-run {run}, after your feedback.",
        "exec.departures": "Departures from the plan, as reported by the executor",
        "exec.step": "Step {i}: {description}", "exec.planned": "Planned method",
        "exec.fixed": "{n} failed attempt(s) were fixed before this one.", "exec.output": "Output",
        "exec.nothing": "(nothing printed)", "exec.error": "Error",
        "exec.skipped": "{n} later step(s) were not run because a step failed.", "exec.script": "Full script",
        "exec.table": "| step | what | status | fixed errors | departures from plan | figures |",
        "exec.read_first": "Read the departures from the plan first: they are where the executor made a choice "
                           "the plan did not.",
        "exec.not_run": "step(s) not run",
        "interp.path": "Path", "interp.verdict": "Verdict", "interp.adherence": "Did the execution follow the plan?",
        "interp.assumptions": "Assumption checks", "interp.findings": "Findings", "interp.issues": "Issues",
        "interp.evidence": "Evidence", "interp.caveat": "Caveat", "interp.confidence": "{level} confidence",
        "interp.recommendation": "Recommendation to the planner", "interp.recommends": "Recommends",
        "interp.concerns": "Assumptions in doubt", "interp.figures": "Figures", "interp.fix": "Proposed fix",
        "question.intro": "The planner needs your input before it can continue.", "question.why": "Why",
        "question.evidence": "What prompted it", "question.recommended": "recommended",
        "help.brief": "approve: start planning (any feedback is added as a note for all agents)",
        "help.plan": "approve: run the selected paths (or accept finishing) | revise: re-plan with your feedback",
        "help.execution": "approve: pass to the interpreter (feedback becomes a note for it) | revise: re-run with your feedback",
        "help.interpretation": "approve: back to the planner (feedback becomes a note for it) | override: replace the "
                               "verdict | revise: re-interpret with your feedback",
        "help.question": "approve: send your answers to the planner",
        # brief and analysis tree; the agents always get these English ones
        "r.goal": "Goal", "r.constraints": "Constraints",
        "r.dataset": "Dataset `{name}` ({rows} rows x {cols} cols)", "r.loaded": "Loaded in the session as `{name}`.",
        "r.columns": "| column | dtype | missing | unique | summary |",
        "r.file": "Context file", "r.note": "User note", "r.query": "User question / query",
        "r.empty": "(empty: nothing has been executed yet; the session has only the datasets loaded)",
        "r.node": "node `{id}` (from `{parent}`): {title}", "r.planned": "planned, not executed",
        "r.not_interpreted": "executed: {status}, not interpreted", "r.verdict": "verdict",
        "r.override": "USER OVERRIDE; interpreter said {verdict}", "r.user": "USER ({stage} review, {action})",
        "r.finding": "finding ({level})", "r.issue": "issue", "r.fix": "proposed fix",
        "r.recommends": "interpreter recommends", "r.objects": "session objects",
        # data profiles (ingest): what the agents and the start form show for each column
        "prof.bool": "bool; true={n}", "prof.numeric": "min={min}, median={median}, mean={mean}, max={max}, sd={sd}",
        "prof.few": "; only {n} distinct values (possibly categorical/ordinal)", "prof.all_missing": "all missing",
        "prof.dates": "from {start} to {end}", "prof.levels": "{n} levels; top: {levels}",
        # coded values as shown in review documents (English shows the codes themselves)
        "code.done": "done", "code.failed": "failed", "code.partial": "partial",
        "code.continue": "continue", "code.complete": "complete", "code.need_user_input": "need_user_input",
        "code.proceed": "proceed", "code.retry": "retry", "code.revise": "revise", "code.abandon": "abandon",
        "code.goal_met": "goal_met", "code.low": "low", "code.medium": "medium", "code.high": "high",
        "code.holds": "holds", "code.concern": "concern", "code.fails": "fails", "code.unclear": "unclear",
        "code.data_quality": "Data-quality check", "code.prepare": "Prepare", "code.describe": "Describe",
        "code.model": "Model",
        # activity log in the review interface's working view
        "log.plan_round": "planner: round {round}", "log.plan_revise": "planner: round {round} (revising after your feedback)",
        "log.plan_done": "planner: {decision}, {n} path(s)",
        "log.exec_step": "executor: {node} step {i} of {n}: {what}", "log.exec_done": "executor: {node} step {i} {status}",
        "log.exec_error": "executor: attempt {i} raised {error}; fixing",
        "log.exec_fit": "executor: output shows {hits}; checking the fit is real",
        "log.interp_verdict": "interpreter: {node} verdict {verdict}", "log.report": "interpreter: writing the final report",
        # server messages shown in the interface
        "err.running": "An analysis is running; wait for it to reach a review point.",
        "err.nothing_waiting": "Nothing is waiting for your response.",
        "err.branch_busy": "You can only branch from a past review point while nothing is running.",
        "err.no_point": "There is no review point {id}.",
        "err.cannot_branch": "That review point cannot be branched from.",
        "err.switch_busy": "Wait for the agent to finish before switching branch.",
        "err.no_project": "There is no saved project at {path}.", "err.no_data": "There is no such dataset to download.", "err.delete": "The project is removed from the list, but some of its files could not be deleted: {error}\nClose anything that may be using them (OneDrive syncing, File Explorer, an editor), then delete the folder by hand: {path}", "err.no_branch": "There is no branch {id}.", "err.no_retry": "There is nothing to retry.",
        "err.action": "'{action}' is not available at a {stage} review point.",
        "err.say_change": "Please say what should change.", "err.choose_verdict": "Choose the verdict to override to.",
        "err.answer": "Please answer the planner's question.", "err.language": "Unknown language {lang!r}.",
        "err.answer_all": "Please answer every question (choose an answer or write your own).",
        "err.no_r": "R is not available: install R and the R-Instat packages (scripts/install_r_packages.R), "
                    "or set ANALYST_RSCRIPT to the Rscript executable.",
    },
    "fr": {
        "glance": "En bref",
        "brief.intro": "Voici ce sur quoi les agents vont travailler. Vérifiez que l'objectif dit bien ce que vous "
                       "voulez, et que les profils des données sont corrects.",
        "brief.goal": "Objectif", "brief.data": "Données", "brief.context": "Éléments de contexte", "brief.none": "(aucune)",
        "brief.dataset": "`{name}` : {rows} lignes x {cols} colonnes ({missing} colonnes avec des valeurs manquantes)",
        "title.brief": "Cadrage", "title.plan": "Plan, tour {round}",
        "title.finish": "Le planificateur propose de terminer", "title.question": "Le planificateur a une question",
        "title.execution": "Exécution de {node} : {path}", "title.interpretation": "Interprétation de {node} : {path}",
        "title.report": "Rapport final",
        "plan.situation": "Lecture de la situation par le planificateur", "plan.decision": "Décision",
        "plan.rationale": "Justification",
        "plan.finish": "Le planificateur propose de **terminer** et de rédiger le rapport. Approuvez pour terminer, "
                       "ou révisez pour indiquer ce qui manque encore.",
        "plan.branches_from": "À partir de", "plan.path": "Piste {i} : {title}", "plan.purpose": "Objet",
        "plan.method": "Méthode", "plan.expected": "Résultat attendu", "plan.evaluate": "Évalué à la fin",
        "plan.criteria": "Critères de réussite", "plan.assumptions": "Hypothèses à vérifier",
        "plan.so_far": "L'analyse jusqu'ici", "plan.why": "Pourquoi ces pistes", "plan.situation_short": "Situation",
        "plan.branching": "À partir de `{parent}` :", "plan.table": "| # | piste | étapes | méthodes |",
        "plan.phase": "Phase",
        "exec.path": "Piste", "exec.status": "Statut", "exec.steps_done": "{done} étape(s) sur {total} réalisée(s)",
        "exec.rerun": "Ceci est la relance n° {run}, après votre retour.",
        "exec.departures": "Écarts par rapport au plan, signalés par l'exécutant",
        "exec.step": "Étape {i} : {description}", "exec.planned": "Méthode prévue",
        "exec.fixed": "{n} tentative(s) en échec ont été corrigées avant celle-ci.", "exec.output": "Sortie",
        "exec.nothing": "(rien d'affiché)", "exec.error": "Erreur",
        "exec.skipped": "{n} étape(s) suivante(s) n'ont pas été exécutées, car une étape a échoué.",
        "exec.script": "Script complet",
        "exec.table": "| étape | quoi | statut | erreurs corrigées | écarts au plan | figures |",
        "exec.read_first": "Lisez d'abord les écarts au plan : ce sont les choix que l'exécutant a faits et que le "
                           "plan ne prévoyait pas.",
        "exec.not_run": "étape(s) non exécutée(s)",
        "interp.path": "Piste", "interp.verdict": "Verdict", "interp.adherence": "L'exécution a-t-elle suivi le plan ?",
        "interp.assumptions": "Vérification des hypothèses", "interp.findings": "Constats", "interp.issues": "Problèmes",
        "interp.evidence": "Éléments", "interp.caveat": "Réserve", "interp.confidence": "confiance : {level}",
        "interp.recommendation": "Recommandation au planificateur", "interp.recommends": "Recommande",
        "interp.concerns": "Hypothèses douteuses", "interp.figures": "Figures", "interp.fix": "Correction proposée",
        "question.intro": "Le planificateur a besoin de votre avis pour continuer.", "question.why": "Pourquoi",
        "question.evidence": "Ce qui l'a motivée", "question.recommended": "recommandé",
        "help.brief": "approuver : lancer la planification (tout retour est ajouté comme note pour tous les agents)",
        "help.plan": "approuver : exécuter les pistes choisies (ou accepter de terminer) | réviser : replanifier selon votre retour",
        "help.execution": "approuver : transmettre à l'interprète (votre retour devient une note pour lui) | réviser : relancer selon votre retour",
        "help.interpretation": "approuver : retour au planificateur (votre retour devient une note pour lui) | remplacer : "
                               "changer le verdict | réviser : réinterpréter selon votre retour",
        "help.question": "approuver : envoyer vos réponses au planificateur",
        "r.goal": "Objectif", "r.constraints": "Contraintes",
        "r.dataset": "Jeu de données `{name}` ({rows} lignes x {cols} colonnes)",
        "r.loaded": "Chargé dans la session sous le nom `{name}`.",
        "r.columns": "| colonne | type | manquantes | distinctes | résumé |",
        "r.file": "Fichier de contexte", "r.note": "Note de l'utilisateur", "r.query": "Question ou requête de l'utilisateur",
        "r.empty": "(vide : rien n'a encore été exécuté ; la session ne contient que les jeux de données)",
        "r.node": "nœud `{id}` (depuis `{parent}`) : {title}", "r.planned": "prévu, non exécuté",
        "r.not_interpreted": "exécuté : {status}, non interprété", "r.verdict": "verdict",
        "r.override": "REMPLACÉ PAR L'UTILISATEUR ; l'interprète avait dit {verdict}",
        "r.user": "UTILISATEUR (validation {stage}, {action})",
        "r.finding": "constat ({level})", "r.issue": "problème", "r.fix": "correction proposée",
        "r.recommends": "l'interprète recommande",
        "r.objects": "objets de la session",
        "prof.bool": "booléen ; vrai = {n}",
        "prof.numeric": "min = {min} ; médiane = {median} ; moyenne = {mean} ; max = {max} ; é.-t. = {sd}",
        "prof.few": " ; seulement {n} valeurs distinctes (peut-être catégorielle ou ordinale)",
        "prof.all_missing": "toutes manquantes", "prof.dates": "du {start} au {end}",
        "prof.levels": "{n} modalités ; les plus fréquentes : {levels}",
        "code.done": "terminée", "code.failed": "en échec", "code.partial": "partielle",
        "code.continue": "continuer", "code.complete": "terminer", "code.need_user_input": "question à l'utilisateur",
        "code.proceed": "continuer", "code.retry": "réessayer", "code.revise": "réviser", "code.abandon": "abandonner",
        "code.goal_met": "objectif atteint", "code.low": "faible", "code.medium": "moyenne", "code.high": "élevée",
        "code.holds": "vérifiée", "code.concern": "à surveiller", "code.fails": "non vérifiée", "code.unclear": "indéterminée",
        "code.data_quality": "Contrôle de la qualité des données", "code.prepare": "Préparer", "code.describe": "Décrire",
        "code.model": "Modéliser",
        "log.plan_round": "planificateur : tour {round}", "log.plan_revise": "planificateur : tour {round} (révision après votre retour)",
        "log.plan_done": "planificateur : {decision}, {n} piste(s)",
        "log.exec_step": "exécutant : {node}, étape {i} sur {n} : {what}", "log.exec_done": "exécutant : {node}, étape {i} {status}",
        "log.exec_error": "exécutant : la tentative {i} a levé {error} ; correction",
        "log.exec_fit": "exécutant : la sortie montre {hits} ; vérification que l'ajustement est réel",
        "log.interp_verdict": "interprète : {node}, verdict {verdict}", "log.report": "interprète : rédaction du rapport final",
        "err.running": "Une analyse est en cours ; attendez qu'elle atteigne un point de validation.",
        "err.nothing_waiting": "Rien n'attend votre réponse.",
        "err.branch_busy": "On ne peut créer une branche à partir d'un point passé que lorsque rien n'est en cours.",
        "err.no_point": "Il n'y a pas de point de validation {id}.",
        "err.cannot_branch": "On ne peut pas créer de branche à partir de ce point de validation.",
        "err.switch_busy": "Attendez que l'agent ait terminé avant de changer de branche.",
        "err.no_project": "Il n'y a pas de projet enregistré à {path}.", "err.no_data": "Ce jeu de données n'existe pas.", "err.delete": "Le projet est retiré de la liste, mais certains de ses fichiers n'ont pas pu être supprimés : {error}\nFermez ce qui peut les utiliser (synchronisation OneDrive, Explorateur de fichiers, un éditeur), puis supprimez le dossier à la main : {path}", "err.no_branch": "Il n'y a pas de branche {id}.", "err.no_retry": "Il n'y a rien à relancer.",
        "err.action": "« {action} » n'est pas possible à un point de validation de type {stage}.",
        "err.say_change": "Indiquez ce qui doit changer.", "err.choose_verdict": "Choisissez le verdict de remplacement.",
        "err.answer": "Répondez à la question du planificateur.", "err.language": "Langue inconnue : {lang!r}.",
        "err.answer_all": "Répondez à chaque question (choisissez une réponse ou écrivez la vôtre).",
        "err.no_r": "R n'est pas disponible : installez R et les packages R-Instat (scripts/install_r_packages.R), "
                    "ou indiquez l'exécutable Rscript dans ANALYST_RSCRIPT.",
    },
}

# The agents' per-call prompts: the wording wrapped around the brief, the plan, the code and its
# output. Each language has its own, so a French analysis is French end to end (with the French
# role texts and playbooks); placeholders are filled in by the agents.
PROMPTS: dict[str, dict[str, str]] = {
    "en": {
        # planner
        "plan.brief": "# Brief", "plan.state": "# Current analysis state",
        "plan.revision": "# The user sent your previous proposal back\n\nYour proposal:\n```json\n{proposal}\n```\n\n"
                         "The user's feedback: {feedback}\n\nRevise the proposal to address the feedback. The user's steer "
                         "takes precedence over your own preference; if you think it is statistically unsound, say so in "
                         "`rationale` and propose the closest sound alternative.",
        "plan.no_feedback": "(none given)",
        "plan.budget": "# Budget\nPlanning round {round} of at most {max}. ",
        "plan.last_round": "This is the last round: plan only what is essential to answer the goal, or complete.",
        "plan.task": "Decide the next step: one path that does one major thing, or a question for the user.",
        "plan.none_selected": "The user selected none of the paths.",
        # executor
        "exec.path": "# Path being executed", "exec.done": "# Steps already run in this path", "exec.none_yet": "(none yet)",
        "exec.task": "# Your task\n\nWrite the code for step {i} only.",
        "exec.user_plan": "The user's instructions count as part of the plan: follow them exactly, as you would the planner's.",
        "exec.rerun": "This is re-run {run} of this path, requested by the user after reviewing the previous run.",
        "exec.failed": "# Attempt {i} failed\n```{fence}\n{code}\n```\nOutput before the error:\n{out}\nError:\n{error}\n\n"
                       "Fix the code without changing what the step computes. If the step cannot be done as written, "
                       "set achievable=false and explain.",
        "exec.not_achievable": "Not achievable as written: {notes}",
        "exec.fit_failed": "Not achievable as written (fit failed): {notes}",
        "exec.gave_up": "Gave up after {n} attempts.",
        "exec.review": "# Step {i} of the path\n\n{description}\nMethod: {method}\n\n# Code that ran\n```{fence}\n{code}\n```\n\n"
                       "# Output\n```\n{out}\n```\n\nThe output contains possible fit-failure signs: {hits}.\n\n"
                       "Apply the playbook's 'Check that a fit is real' rules. Did the method actually work?",
        "exec.summary": "## Step {i} ({status})\n```{fence}\n{code}\n```\nOutput (tail):\n{out}",
        # interpreter
        "interp.brief": "# Brief", "interp.earlier": "# Earlier results", "interp.plan": "# Plan for node `{node}`",
        "interp.execution": "# Execution (status: {status})", "interp.task": "Interpret this node.",
        "interp.step": "## Step {i}: {status}", "interp.deviations": "Changes the executor made to the instructions, with its reasons:",
        "interp.failed_attempt": "### Failed attempt {i} (retried below)", "interp.code": "### Code",
        "interp.output": "### Output", "interp.error": "### Error", "interp.figures": "Figures: ",
        "interp.not_attached": " (not attached: figure limit)",
        "interp.skipped": "({n} later step(s) not run because an earlier step failed.)",
        "interp.truncated": "[output truncated]",
        "report.results": "# Interpreted results",
        "report.task": "Analysis ended with status: {status}.\n\nWrite the report in Markdown.",
        # path and user notes, as the agents see them
        "path.purpose": "Purpose", "path.steps": "Steps", "path.method": "method", "path.expected": "expected output",
        "path.code": "suggested code", "path.evaluate": "Evaluate at the end", "path.criteria": "Success criteria",
        "path.assumptions": "Assumptions to check",
        "notes.head": "# From the user who is reviewing this analysis\n\nThese notes take precedence over your own "
                      "judgement where they conflict.",
        "notes.item": "({stage} review, {action})",
        "ctx.brief_review": "user (brief review)", "ctx.answer": "user (answer)", "ctx.qa": "Q: {q}\nA: {a}",
        "ctx.no_answer": "(not answered)", "ctx.extra": "Also: {text}",
        "fig.not_shown": "\n\n(Note: {n} figure(s) were produced but cannot be shown to this model. Judge from the "
                         "printed output, and say which visual checks you could not make.)",
    },
    "fr": {
        "plan.brief": "# Cadrage", "plan.state": "# État actuel de l'analyse",
        "plan.revision": "# L'utilisateur vous a renvoyé votre proposition précédente\n\nVotre proposition :\n```json\n"
                         "{proposal}\n```\n\nRetour de l'utilisateur : {feedback}\n\nRévisez la proposition pour répondre "
                         "à ce retour. L'orientation donnée par l'utilisateur prime sur votre propre préférence ; si vous "
                         "la jugez statistiquement infondée, dites-le dans `rationale` et proposez l'alternative solide la "
                         "plus proche.",
        "plan.no_feedback": "(aucun)",
        "plan.budget": "# Budget\nTour de planification {round} sur {max} au plus. ",
        "plan.last_round": "C'est le dernier tour : ne planifiez que l'essentiel pour répondre à l'objectif, ou terminez.",
        "plan.task": "Décidez de la prochaine étape : une seule piste qui fait une seule chose majeure, ou une question pour l'utilisateur.",
        "plan.none_selected": "L'utilisateur n'a retenu aucune des pistes.",
        "exec.path": "# Piste en cours d'exécution", "exec.done": "# Étapes déjà exécutées dans cette piste",
        "exec.none_yet": "(aucune pour l'instant)",
        "exec.task": "# Votre tâche\n\nÉcrivez le code de l'étape {i} uniquement.",
        "exec.user_plan": "Les consignes de l'utilisateur font partie du plan : suivez-les exactement, comme celles du "
                          "planificateur.",
        "exec.rerun": "Ceci est la relance n° {run} de cette piste, demandée par l'utilisateur après examen de "
                      "l'exécution précédente.",
        "exec.failed": "# La tentative {i} a échoué\n```{fence}\n{code}\n```\nSortie avant l'erreur :\n{out}\n"
                       "Erreur :\n{error}\n\nCorrigez le code sans changer ce que l'étape calcule. Si l'étape ne peut "
                       "pas être réalisée telle qu'écrite, mettez achievable=false et expliquez pourquoi.",
        "exec.not_achievable": "Non réalisable tel qu'écrit : {notes}",
        "exec.fit_failed": "Non réalisable tel qu'écrit (échec de l'ajustement) : {notes}",
        "exec.gave_up": "Abandon après {n} tentatives.",
        "exec.review": "# Étape {i} de la piste\n\n{description}\nMéthode : {method}\n\n# Code exécuté\n```{fence}\n"
                       "{code}\n```\n\n# Sortie\n```\n{out}\n```\n\nLa sortie contient des signes possibles d'échec de "
                       "l'ajustement : {hits}.\n\nAppliquez les règles du guide « Vérifier qu'un ajustement est réel ». "
                       "La méthode a-t-elle réellement fonctionné ?",
        "exec.summary": "## Étape {i} ({status})\n```{fence}\n{code}\n```\nSortie (fin) :\n{out}",
        "interp.brief": "# Cadrage", "interp.earlier": "# Résultats précédents", "interp.plan": "# Plan du nœud `{node}`",
        "interp.execution": "# Exécution (statut : {status})", "interp.task": "Interprétez ce nœud.",
        "interp.step": "## Étape {i} : {status}", "interp.deviations": "Modifications apportées aux consignes par l'exécutant, avec ses raisons :",
        "interp.failed_attempt": "### Tentative {i} en échec (corrigée plus bas)", "interp.code": "### Code",
        "interp.output": "### Sortie", "interp.error": "### Erreur", "interp.figures": "Figures : ",
        "interp.not_attached": " (non jointe : limite de figures atteinte)",
        "interp.skipped": "({n} étape(s) suivante(s) non exécutée(s), car une étape précédente a échoué.)",
        "interp.truncated": "[sortie tronquée]",
        "report.results": "# Résultats interprétés",
        "report.task": "L'analyse s'est terminée avec le statut : {status}.\n\nRédigez le rapport en Markdown.",
        "path.purpose": "Objet", "path.steps": "Étapes", "path.method": "méthode", "path.expected": "résultat attendu",
        "path.code": "code suggéré", "path.evaluate": "À évaluer à la fin", "path.criteria": "Critères de réussite",
        "path.assumptions": "Hypothèses à vérifier",
        "notes.head": "# De la part de l'utilisateur qui valide cette analyse\n\nCes notes priment sur votre propre "
                      "jugement en cas de désaccord.",
        "notes.item": "(validation {stage}, {action})",
        "ctx.brief_review": "utilisateur (validation du cadrage)", "ctx.answer": "utilisateur (réponse)",
        "ctx.qa": "Q : {q}\nR : {a}", "ctx.no_answer": "(pas de réponse)", "ctx.extra": "En outre : {text}",
        "fig.not_shown": "\n\n(Remarque : {n} figure(s) ont été produites mais ne peuvent pas être montrées à ce modèle. "
                         "Jugez d'après la sortie affichée, et dites quelles vérifications visuelles vous n'avez pas pu faire.)",
    },
}


def t(lang: str, key: str, **kw) -> str:
    """Wording of documents, labels and server messages."""
    text = STRINGS.get(lang, STRINGS[DEFAULT]).get(key) or STRINGS[DEFAULT][key]
    return text.format(**kw) if kw else text


def code(lang: str, value: str) -> str:
    """A coded value (status, decision, verdict, confidence) as a word in the language; English keeps the code."""
    return STRINGS.get(lang, STRINGS[DEFAULT]).get(f"code.{value}", value)


def p(lang: str, key: str, **kw) -> str:
    """Wording of an agent prompt."""
    text = PROMPTS.get(lang, PROMPTS[DEFAULT]).get(key) or PROMPTS[DEFAULT][key]
    return text.format(**kw) if kw else text


def number(x: float, lang: str, fmt: str = ".4g") -> str:
    """A number as the language writes it: 3.94 in English, 3,94 in French."""
    s = format(x, fmt)
    return s.replace(".", ",") if lang == "fr" else s


def check(lang: str) -> str:
    if lang not in LANGUAGES:
        raise ValueError(t(DEFAULT, "err.language", lang=lang))
    return lang
